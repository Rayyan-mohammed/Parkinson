check_and_install_package <- function (libNames) {
    installBioConPackage <- function (libName) {
        message (paste0("Package ", libName, " need to be installed.\n"))
        source("http://www.bioconductor.org/biocLite.R")
        biocLite(libName)
    }
    for (libName in libNames) {
        if (!(libName %in% installed.packages())) {
            installBioConPackage(libName)
            if ((libName %in% installed.packages())) {
                message (paste0("Package ", libName, " is successfully installed.\n"))
            } else {
                message (paste0("Package ", libName, " is failed to be installed.\n"))
            }
        }
    }
}