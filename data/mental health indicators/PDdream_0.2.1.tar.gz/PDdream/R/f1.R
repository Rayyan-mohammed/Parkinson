# f1 maps [0,infinity) to [0,1]
f1 <- function(x,a,b)
{
    eax <- exp(a*x)
    if (eax == Inf)
        f1eax <- 1
    else
        f1eax <- (eax-1)/(eax+b)
    return(f1eax)
}

# f2 maps [0,1] onto [0,1]
f2 <- function(x,a,b)
{
    eax <- exp(a*x)
    ea <- exp(a)
    return((eax-1)/(eax+b)*(ea+b)/(ea-1))
}