#source("~/mybiotools/r/myfunc.R")
options(
    "scipen" = 1,
    "digits" = 4,
    stringsAsFactors = FALSE,
    drop = F
)

functions = c(
    "four_digit_year_transfor",
    "region_match",
    "multiClassSummary2",
    "detach_package",
    "get_R_mem",
    "get_R_objects_mem",
    "getFileNameExtension",
    "getFileNamePrefix",
    "split_samples",
    "tablef",
    "calc_call_rate",
    "plot_Y_callrate",
    "splitdf",
    "jitter_plot",
    "rem.snp.allele",
    "bagging_pred",
    "add_phe",
    "plot_accu",
    "plot_accu_v2",
    "binomial_continous",
    "my_rowname",
    "get_phenotype",
    "empty.num",
    "na.num",
    "nonna.num",
    "merge2col",
    "merge_all_col",
    "check_phe",
    "pcaCharts",
    "gene_symbol_trim",
    "mysubset",
    "get_H",
    "draw_pca_with_color",
    "draw_pca_without_color",
    "r.table",
    "w.table",
    "glmnet.cv",
    "svm.cv",
    "nnet.cv",
    "rf.cv",
    "nb.cv",
    "my_pred_plot",
    "my_roc",
    "prediction_ROC",
    "pvadj",
    "prediction_ROC_nopdf",
    "replace_zero_value",
    "add.alpha",
    "sum.rm.na",
    "sum.rm.na.numeric",
    "sum.rm.na.logical",
    "sum.rm.na.data.frame",
    "sum.rm.na.matrix",
    "mean.rm.na.numeric",
    "median.rm.na.numeric",
    "rf_impute",
    "showCols",
    "myscale",
    "showfunc",
    "max.rm.na.numeric",
    "min.rm.na.numeric",
    "perm.p",
    "caret_predict",
    "scale_to_num",
    "remove_pv_zero",
    "my_demography",
    "my_demography_fisher",
    "my_demography_no_response",
    "num2LetterFactor",
    "legend.col"
)

num2LetterFactor = function(response) {
    #used to transforming a number/factor
    #to factor with corrent number of levels
    #and with caret supported format
    require(caret)
    response = factor(response)
    res.lev = levels(response)
    if (sum(table(response) == 0) > 0) {
        zero.i = which(table(Y1) == 0)
        res.lev = levels(response)[-zero.i]
    }
    new.level = make.names(res.lev)
    levels(response) = new.level
    response
}

region_match = function(gene_info,
                        chr,
                        start,
                        end,
                        sort.col = NULL,
                        decreasing = T) {
    #gene_info is a data.frame with three cols: chr, start, end
    #chr, start, end: destination region
    #sort.col, if is not NULL, only one of rows will return, according to order of this column
    #return the rows with crossed regions
    chr.info = gene_info[which(gene_info$chr == chr), ]
    nonDest.i1 = which(start < chr.info$start &
                           end < chr.info$start)
    #non destination index
    nonDest.i2 = which(start > chr.info$end   & end > chr.info$end)
    
    nonDest.i = unique(c(nonDest.i1, nonDest.i2))
    
    g.info = chr.info[-nonDest.i, , drop = F]
    
    if (nrow(g.info) > 1 & !is.null(sort.col)) {
        #means only one row returned
        m.i.n = order(as.numeric(g.info[, sort.col], decreasing = decreasing))
        g.info = g.info[m.i.n[1], , drop = F]
    }
    return (g.info)
}

get_R_objects_mem = function(obj, unit = "Mb", ...) {
    #used to watch objects my.mem
    #units is format argu: "b", "Mb", "Gb", "Tb", ...
    if (length(obj) < 1)
        stop ("Error: obj has 0 length")
    my.mem = c()
    for (l in obj) {
        m = format(object.size(l), units = unit)
        my.mem = c(my.mem, m)
    }
    names(my.mem) = obj
    my.mem
    
    #example
    # allobj = ls()
    # ret = get_R_objects_mem(allobj, unit="b")
    # ret.d = as.numeric(unlist(strsplit(x = ret, split = " bytes")))
    # sort(ret.d)
}

get_R_mem = function () {
    #to return memory that R script taking
    mem = system(paste0("cat /proc/", Sys.getpid(), "/status | grep VmSize"),
                 intern = T)
    return (mem)
}

getFileNamePrefix <- function (fn) {
    prefix = tools::file_path_sans_ext(basename(fn))
    prefix
}

getFileNameExtension <- function (fn) {
    # remove a path
    splitted    <- strsplit(x = fn, split = '/')[[1]]
    # or use .Platform$file.sep in stead of '/'
    fn          <- splitted [length(splitted)]
    ext         <- ''
    splitted    <- strsplit(x = fn, split = '\\.')[[1]]
    l           <- length (splitted)
    if (l > 1 && sum(splitted[1:(l - 1)] != ''))
        ext <- splitted [l]
    # the extention must be the suffix of a non-empty name
    ext
}

tablef = function (x) {
    #this function preserve the original orders of table elements
    #x is a vector to be tabled
    ret = table(factor(x, levels = unique(x)))
    name = names(ret)
    number = as.numeric(ret)
    return (list(
        name = name,
        number = number,
        table = ret
    ))
}

showfunc = function (pattern = NULL, ...) {
    #arg1: grep patter
    #arg 2...: grep other parameters
    #values: all function names
    if (is.null(pattern)) {
        funcs = functions
        cat ("All available functions: ", "\n\n")
    } else {
        f.i = grep (pattern = pattern, x = functions, ...)
        funcs = functions[f.i]
        cat ("Functions with pattern of ", pattern, ": ", "\n\n")
    }
    cat(funcs, sep = "\n")
}

#change to 2000+ year
four_digit_year_transfor <- function (date.input, split.year = 20) {
    #split.year is used to determine the year belongs to 1900+ or 2000+ according to > split.year or not
    
    
    check_and_install_package("lubridate")
    library(lubridate)
    if (!is.Date(date.input))
        stop ("date.input must be Date object.")
    date.input.ret = date.input
    gt2000.i = which(year(date.input) < split.year &
                         nchar(year(date.input)) <= 2) # 2000 +
    if (length(gt2000.i > 0))
        year(date.input.ret[gt2000.i]) = 2000 + year(date.input.ret[gt2000.i])
    lt2000.i = which(year(date.input) > split.year &
                         nchar(year(date.input)) <= 2) # 1900 +
    if (length(lt2000.i > 0))
        year(date.input.ret[lt2000.i]) = 1900 + year(date.input.ret[lt2000.i])
    just_split_year.i = which(year(date.input) == split.year) # 1900 +
    if (length(just_split_year.i > 0))
        stop ("Cannot determine because there are values equal to split.year.")
    return (date.input.ret)
}

plot_Y_callrate = function (dat,
                            main = "",
                            xlab = "Detection P-value Threshold",
                            y1lab = "% Markers in Female with Call-Rate > 5%",
                            y2lab = "% Markers in Female with Call-Rate > 95%",
                            xname,
                            cex = 2,
                            cex.lab = 1,
                            cex.axis = 1,
                            ylim,
                            pv_cutoff.set = 1e-12,
                            ...)
{
    #dat should be data matrix
    # 1. pv = pv
    # 2. y1 = female ratio
    # 3. y2 = male ratio
    require("RColorBrewer")
    mycols = colorRampPalette(brewer.pal(9, "Set1"))(8)[1:2]
    par(mar = c(5, 5, 2, 5))
    if (missing(ylim))
        ylim = range(c(dat$y1, dat$y2), na.rm = T)
    with(
        dat,
        plot(
            1:length(pv),
            y1,
            type = "b",
            pch = 19,
            col = mycols[2],
            ann = FALSE,
            xlim = c(1, length(pv)),
            xaxt = "n",
            main = main,
            cex = cex,
            ylim = ylim
        )
    )
    
    xpo = 1:nrow(dat)
    title(
        main = main,
        ylab = y1lab,
        xlab = xlab,
        cex.lab = cex.lab,
        cex.main = cex.lab
    )
    axis(1, xpo, xname,  cex.axis = cex.axis, las = 1)
    par(new = TRUE)
    with(
        dat,
        plot(
            1:length(pv),
            y2,
            type = "b",
            pch = 19,
            col = mycols[1],
            axes = F,
            xlab = NA,
            xlim = c(1, length(pv)),
            ylim = ylim,
            cex = cex,
            ylab = NA
        )
    )
    
    #axis(4, ypo, ypo,    cex.axis=cex.axis, las = 1, ylab)
    axis(side = 4, cex.axis = cex.axis)
    mtext(side = 4,
          line = 3,
          y2lab,
          cex = cex.lab)
    
    #for selected pv
    line.v = which(dat[, "pv"] == pv_cutoff.set)
    if (is.na(line.v))
        stop ("pv_cutoff.set is not in dat[, 1]")
    abline(v = line.v, lwd = 2)
}

calc_call_rate = function (y_pr_detP, pv_cutoff) {
    #cat ("\n", file = log_f,sep="\t", append = T)
    #cat ("Determine best detection Pvalue: \n\n", file = log_f,sep="\t", append = T)
    out.s = c()
    library(doParallel)
    registerDoParallel(cores = length(pv_cutoff))
    #for (pv in pv_cutoff) {
    out.s <-
        foreach (j = 1:length(pv_cutoff), .combine = rbind) %dopar%
        {
            out = c()
            pv = pv_cutoff[j]
            for (i in 1:nrow(y_pr_detP)) {
                p = y_pr_detP[i,]
                call.rate = sum(p < pv) / ncol(y_pr_detP)
                out = c(out, call.rate)
            }
            #cat ("pvalue cutoff: ",pv,"\n",file = log_f,sep="\t", append = T)
            #cat (names(table(out)),file = log_f,sep="\t", append = T)
            #cat ("\n", file = log_f,sep="\t", append = T)
            #cat (as.numeric(table(out)),file = log_f,sep="\t", append = T)
            #cat ("\n", file = log_f,sep="\t", append = T)
            #print(table(out),file = log_f,sep="\t", append = T)
            num.gt005 = sum(out > 0.05)
            num.gt095 = sum(out > 0.95)
            return (c(pv, as.numeric(table(out))[1], num.gt005, num.gt095))
        }
    colnames(out.s) = c("pv.cutoff",
                        "zero_callrate_num",
                        "callrate_num_gt005",
                        "callrate_num_gt095")
    return (out.s)
}

split_samples = function (n,
                          train.ratio = 0.8,
                          ...) {
    # is used to split samples with a given ratio into training and testing datasets
    # return a list with train.i and test.i as index
    s.i = runif(n)
    train.i = which(s.i <= train.ratio)
    #cont.ratio = ifelse (cont.ratio == 1 - train.ratio, cont.ratio, 1 - train.ratio)
    test.i = which(s.i > train.ratio)
    return (list(train.i = train.i, test.i = test.i))
    
}

splitdf <- function(dataframe,
                    seed = 123,
                    ratio = 0.5) {
    if (!is.null(seed))
        set.seed(seed)
    index <- 1:nrow(dataframe)
    trainindex <- sample(index, trunc(length(index) * ratio))
    trainset <- dataframe[trainindex, ]
    testset <- dataframe[-trainindex, ]
    list(trainset = trainset, testset = testset)
}

jitter_plot = function (dat,
                        ylab = NA,
                        cols = 5,
                        cex.lab = 14,
                        cex.main = 18,
                        states) {
    check_and_install_package("ggplot2")
    library(ggplot2)
    check_and_install_package("ggpubr")
    library(ggpubr)
    check_and_install_package("Rmisc")
    library(Rmisc)
    
    cbbPalette <- c("#0072B2", "#D55E00")
    plots3 = list()
    plots1 = list()
    plots2 = list()
    i = 1
    for (pr in rownames(dat)) {
        dat2 = data.frame(states = states, probe = as.numeric(dat[pr, , drop = F]))
        if (is.na(ylab))
            ylab = ""
        p1 = qplot(
            states,
            probe,
            data = dat2,
            geom = c("boxplot", "jitter"),
            colour = states,
            ylab = ylab,
            main = paste0("           ", pr),
            xlab = ""
        ) +
            scale_colour_manual(values = cbbPalette) +
            theme(legend.position = "none")
        
        p2 = ggplot(data = dat2,
                    aes(x = states, y = probe)) +
            geom_violin(aes(fill = states), alpha = 0.6) +
            geom_jitter(aes(color = states), alpha = 0.8)  +
            ylab(ylab) +
            ggtitle(paste0("           ", pr)) +
            xlab("") +
            #scale_color_discrete(name = "type") +
            scale_colour_manual(values = cbbPalette) +
            scale_fill_manual(values = cbbPalette) +
            theme(legend.position = "none")
        
        p3 = ggviolin(
            dat2,
            #cex.axis = cex.lab,
            #cex.lab = cex.lab,
            x = "states",
            y = "probe",
            size = 1,
            fill = "states",
            palette = cbbPalette,
            add = "boxplot",
            add.params = list(fill = "white")
        )
        p3 = ggpar(
            p3,
            main = paste0("       ", pr),
            xlab = "",
            ylab = ylab,
            font.main = cex.main,
            font.x = cex.lab,
            font.y = cex.lab,
            legend = "none"
        )
        
        plots1[[i]] <- p1
        plots2[[i]] <- p2
        plots3[[i]] <- p3
        i = i + 1
        
    }
    #multiplot(plotlist = plots3, cols = cols)
    return(list(plots1, plots2, plots3))
}

rem.snp.allele = function(snp.seq) {
    #used to remove plink recodeA SNP name's allel: rs116781904_A --> rs116781904
    snps = unlist(strsplit(snp.seq, "_.$", perl = T))
    return(snps)
}

fisher.matrix = function (dat) {
    #dat should be a two column data matrix
    #values will be nrow of pvalues and estimates
    
    totfi <- apply(dat, 2, sum)
    tablacont <- function (x, total) {
        # x; total: 2 x 1
        m1 <- round(c(x[1], total[1] - x[1]), 0)
        m2 <- round(c(x[2], total[2] - x[2]), 0)
        tt <- rbind(m1, m2)
        colnames(tt) <- c("yes", "no")
        tt
    }
    
    fish.pv <- NULL
    fish.OR <- NULL
    fish.CI <- NULL
    for (g in 1:nrow(dat)) {
        ttt <- tablacont(dat[g,], totfi)
        fit = fisher.test(ttt)
        fish.pv <- c(fish.pv, fit$p.value)
        fish.OR <- c(fish.OR, as.numeric(fit$estimate))
        fish.CI <- rbind(fish.CI, as.numeric(fit$conf.int))
    }
    ret = signif(cbind(fish.pv, fish.OR, fish.CI), 3)
    rownames(ret) = rownames(dat)
    colnames(ret) = c("Pvalue", "OR", "OR.95.CI.low", "OR.95.CI.high")
    return (ret)
}

remove_outliers <- function(x, na.rm = TRUE, ...) {
    qnt <- quantile(x, probs = c(.25, .75), na.rm = na.rm, ...)
    H <- 1.5 * IQR(x, na.rm = na.rm)
    y <- x
    y[x < (qnt[1] - H)] <- NA
    y[x > (qnt[2] + H)] <- NA
    y
}

my_demography_fisher = function (phe,
                                 outf = "fisher_test.tab",
                                 response,
                                 #the levels seq should be (exposed, unexposed)
                                 if.need.rev.response = T,
                                 #if the levels seq need to be reversed to be (exposed, unexposed)
                                 if.cont2factor = F,
                                 #if need to transform cont to factor
                                 if.remove.outliers = F,
                                 #if need to remove outliers
                                 cont2factor.divide.num = 5,
                                 #if if.cont2factor == T, then dividing the digits into cont2factor.divide.num parts, and making cont2factor.divide.num levels factor
                                 pheno.factor,
                                 pheno.cont) {
    options(
        "scipen" = -1,
        "digits" = 3,
        stringsAsFactors = FALSE
    )
    options(na.rm = T)
    
    #QC:
    diff.n = setdiff(pheno.factor, colnames(phe))
    if (length(diff.n) > 0)
        stop (paste0("Not all pheno.factor elements in phe: ", diff.n))
    diff.n = setdiff(pheno.cont, colnames(phe))
    if (length(diff.n) > 0)
        stop (paste0("Not all pheno.cont elements in phe: ", diff.n))
    #removing NA columns
    rem.na.h = function (phe1) {
        na.num = apply(phe1, 2, na.num)
        na.i = which(na.num > nrow(phe1) / 2)
        phe2 = phe1
        if (length(na.i) > 0) {
            na.name = names(na.num)[na.i]
            na.i.phe = match(na.name, colnames(phe1))
            phe2 = phe1[,-na.i.phe]
        }
        return (phe2)
    }
    phe1 = rem.na.h(phe)
    phe = phe1
    na.i.factor = match(pheno.factor, names(phe))
    na.i = which(is.na(na.i.factor))
    if (length(na.i) > 0)
        pheno.factor = pheno.factor[-na.i]
    na.i.factor = match(pheno.cont, names(phe))
    na.i = which(is.na(na.i.factor))
    if (length(na.i) > 0)
        pheno.cont = pheno.cont[-na.i]
    
    #remove outliers
    if (if.remove.outliers) {
        for (p in pheno.cont) {
            phe[, p] = remove_outliers(phe[, p])
        }
    }
    
    #transforming to factor
    if (if.cont2factor) {
        for (p in pheno.cont) {
            cat ("Transforming ", p, "\n", sep = "")
            breaks = quantile(
                phe[, p],
                probs = seq(0, 1, 1 / cont2factor.divide.num),
                na.rm = T
            )
            if (sum(duplicated(breaks)) > 0) {
                phe[, p] = cut(phe[, p], breaks = cont2factor.divide.num)
            } else {
                phe[, p] = cut(phe[, p], breaks = breaks)
            }
            pheno.factor = c(pheno.factor, p)
        }
        pheno.cont = c()
    }
    resp.d = as.factor(phe[, response])
    if (if.need.rev.response) {
        resp.d = relevel(resp.d, levels(resp.d)[2])
    }
    
    if (length(levels(resp.d)) != 2)
        stop ("response has to be binomial factor.")
    case.i = which(resp.d == levels(resp.d)[1])
    cont.i = which(resp.d == levels(resp.d)[2])
    phe_p = phe[case.i,]
    phe_n = phe[cont.i,]
    dim(phe_p)
    dim(phe_n)
    
    cat(
        "Type",
        "sub-type pheno",
        paste0(response, "=", levels(resp.d)[1], " (%), ", "N=", dim(phe_p)[1]),
        "Count",
        #paste0("ivdused- (%), ", "N=", dim(phe_n)[1]),
        paste0(response, "=", levels(resp.d)[2], " (%), ", "N=", dim(phe_n)[1]),
        "Count",
        "% (N)",
        "Fisher's exact test Pvalue",
        "Odds Ratio",
        "OR.95.CI",
        "\n",
        sep = "\t",
        file = outf,
        append = F
    )
    
    for (p in pheno.factor)
    {
        cat (p, "\n")
        p.d = phe[, p]
        t.1 = table(p.d, phe[, response])
        t.2 = table(p.d)
        #print (t.1)
        dat = c()
        out = c()
        for (l in names(t.2)) {
            count.case = t.1[l, levels(resp.d)[2]]
            count.cont = t.1[l, levels(resp.d)[1]]
            dat = rbind(dat, c(count.cont, count.case))
        }
        fisher.res = fisher.matrix(dat)
        pv = fisher.res[, "Pvalue"]
        or = fisher.res[, "OR"]
        or.95ci = paste0(fisher.res[, "OR.95.CI.low"], "-", fisher.res[, "OR.95.CI.high"])
        print (pv)
        sum.dat = apply(dat, 1, sum)
        perc.dat = round(sum.dat / sum(sum.dat), 3) * 100
        perc.dat.col = round(dat / sum.dat, 3) * 100
        perc.N = paste0(perc.dat, " (", sum.dat, ")")
        out = cbind(
            rep(p, times = length(names(t.2))),
            names(t.2),
            perc.dat.col[, 1],
            dat[, 1],
            perc.dat.col[, 2],
            dat[, 2],
            perc.N,
            pv,
            or,
            or.95ci
        )
        write.table(
            out,
            file = outf,
            col.names = F,
            row.names = F,
            append = T,
            quote = F,
            sep = "\t"
        )
    }
    
    if (length(pheno.cont) == 0)
        return (0)
    cat("\n", "\n", file = outf, append = T)
    cat(
        "Type",
        #paste0("ivdused+ (mean, sd), ", "N=", dim(phe_p)[1]),
        paste0(
            response,
            "=",
            levels(resp.d)[1],
            " (mean, sd), ",
            "N=",
            dim(phe_p)[1]
        ),
        #paste0("ivdused- (mean, sd), ", "N=", dim(phe_n)[1]),
        paste0(
            response,
            "=",
            levels(resp.d)[2],
            " (mean, sd), ",
            "N=",
            dim(phe_n)[1]
        ),
        "Anova test Pvalue",
        "\n",
        sep = "\t",
        file = outf,
        append = T
    )
    
    for (p in pheno.cont)
    {
        mean.case = mean(phe_p[, p], na.rm = T)
        mean.case = round (mean.case, 3)
        sd.case = sd(phe_p[, p], na.rm = T)
        sd.case = round (sd.case, 3)
        
        mean.cont = mean(phe_n[, p], na.rm = T)
        mean.cont = round (mean.cont, 3)
        sd.cont = sd(phe_n[, p], na.rm = T)
        sd.cont = round (sd.cont, 3)
        
        x = c(phe_p[, p], phe_n[, p])
        group = factor(c(rep(letters[1], length(phe_p[, p])), rep(letters[2], length(phe_n[, p]))))
        fit.2 = errorcast <- try (lm(formula = x ~ group))
        if (class(errorcast) == "try-error") {
            pv = "NA"
            
        } else {
            pv = as.numeric(anova (fit.2)$'Pr(>F)'[1])
        }
        
        cat(
            p,
            paste0(mean.case, ', ', sd.case),
            paste0(mean.cont, ', ', sd.cont),
            pv,
            "\n",
            sep = "\t",
            file = outf,
            append = T
        )
    }
    
}

my_demography = function (phe,
                          outf = "demography.tab",
                          response,
                          pheno.factor,
                          pheno.cont) {
    #response shoule be a factor, with levels[1] control and levels[2] case
    options(
        "scipen" = 1,
        "digits" = 4,
        stringsAsFactors = FALSE
    )
    options(na.rm = T)
    
    #QC:
    diff.n = setdiff(pheno.factor, colnames(phe))
    if (length(diff.n) > 0)
        stop (paste0("Not all pheno.factor elements in phe: ", diff.n))
    diff.n = setdiff(pheno.cont, colnames(phe))
    if (length(diff.n) > 0)
        stop (paste0("Not all pheno.cont elements in phe: ", diff.n))
    
    resp.d = as.factor(phe[, response])
    if (length(levels(resp.d)) != 2)
        stop ("response has to be binomial factor.")
    cont.i = which(resp.d == levels(resp.d)[1])
    case.i = which(resp.d == levels(resp.d)[2])
    phe_p = phe[case.i,]
    phe_n = phe[cont.i,]
    dim(phe_p)
    dim(phe_n)
    
    cat(
        "Type",
        "sub-type pheno",
        paste0(response, "=", levels(resp.d)[2], " (%), ", "N=", dim(phe_p)[1]),
        "Count",
        #paste0("ivdused- (%), ", "N=", dim(phe_n)[1]),
        paste0(response, "=", levels(resp.d)[1], " (%), ", "N=", dim(phe_n)[1]),
        "Count",
        "Chi-square test Pvalue",
        "\n",
        sep = "\t",
        file = outf,
        append = F
    )
    
    for (p in pheno.factor)
    {
        cat (p, "\n")
        p.d = phe[, p]
        t.1 = table(p.d, phe[, response])
        t.2 = table(p.d)
        print (t.1)
        for (l in names(t.2)) {
            count.case = t.1[l, levels(resp.d)[2]]
            #ratio.case = round (t.1[l, levels(resp.d)[2]] / sum(t.1[, levels(resp.d)[2]]), 3) * 100
            ratio.case = round (t.1[l, levels(resp.d)[2]] / nrow(phe_p), 3) * 100
            count.cont = t.1[l, levels(resp.d)[1]]
            #ratio.cont = round (t.1[l, levels(resp.d)[1]] / sum(t.1[, levels(resp.d)[1]]), 3) * 100
            ratio.cont = round (t.1[l, levels(resp.d)[1]] / nrow(phe_n), 3) * 100
            pv = chisq.test(t.1)$p.v
            #cat (pv,"\n")
            cat (
                p,
                l,
                ratio.case,
                count.case,
                ratio.cont,
                count.cont,
                pv,
                "\n",
                sep = "\t",
                file = outf,
                append = T
            )
        }
        
    }
    
    cat("\n", "\n", file = outf, append = T)
    cat(
        "Type",
        #paste0("ivdused+ (mean, sd), ", "N=", dim(phe_p)[1]),
        paste0(
            response,
            "=",
            levels(resp.d)[2],
            " (mean, sd), ",
            "N=",
            dim(phe_p)[1]
        ),
        #paste0("ivdused- (mean, sd), ", "N=", dim(phe_n)[1]),
        paste0(
            response,
            "=",
            levels(resp.d)[1],
            " (mean, sd), ",
            "N=",
            dim(phe_n)[1]
        ),
        "Anova test Pvalue",
        "\n",
        sep = "\t",
        file = outf,
        append = T
    )
    
    for (p in pheno.cont)
    {
        mean.case = mean(as.numeric(phe_p[, p]), na.rm = T)
        mean.case = round (mean.case, 3)
        sd.case = sd(phe_p[, p], na.rm = T)
        sd.case = round (sd.case, 3)
        
        mean.cont = mean(as.numeric(phe_n[, p]), na.rm = T)
        mean.cont = round (mean.cont, 3)
        sd.cont = sd(phe_n[, p], na.rm = T)
        sd.cont = round (sd.cont, 3)
        
        
        x = c(phe_p[, p], phe_n[, p])
        group = factor(c(rep(letters[1], length(phe_p[, p])), rep(letters[2], length(phe_n[, p]))))
        fit.2 = errorcast <- try (lm(formula = x ~ group))
        if (class(errorcast) == "try-error") {
            pv = "NA"
            
        } else {
            pv = as.numeric(anova (fit.2)$'Pr(>F)'[1])
        }
        
        cat(
            p,
            paste0(mean.case, ', ', sd.case),
            paste0(mean.cont, ', ', sd.cont),
            pv,
            "\n",
            sep = "\t",
            file = outf,
            append = T
        )
    }
    
}

remove_pv_zero = function(P) {
    if (length(which(P == 0)) > 0)
        P[P == 0] = min(P[-which(P == 0)], na.rm = T) / 2
    return (P)
}

scale_to_num = function(dat, maxnum = 100) {
    #scale columns to a number for a data frame
    rname = rownames(dat)
    maxnum = 100
    dat <- data.frame(lapply(dat, function(x)
        scale(
            x,
            center = FALSE,
            scale = max(x, na.rm = TRUE) / maxnum
        )))
    rownames(dat) = rname
    return(dat)
}

caret_predict = function(X, Y, svm.tune)
{
    #in_rdata: datamatrix: X; class: Y
    #model_rdata: train result rdata, svm.tune
    #Value: a list of confM and predinfo
    #load(in_rdata)
    #load(model_rdata)
    #some methods (nb, svm) require same predictors in training and testing data
    x.i = match(colnames(svm.tune$trainingData), colnames(X), nomatch = 0)
    X1 = X[, x.i]
    pred <- predict(svm.tune, newdata = X1)
    pred.prob <- predict(svm.tune, newdata = X1, type = "prob")
    
    if  (length(levels(pred)) > length(levels(Y))) 
    {
        levels(Y) = levels(pred)
    }
    confM = confusionMatrix(pred, Y)
    Correct = (pred == Y)
    out = cbind(pred, pred.prob, Y, Correct)
    return(list(confM = confM, predinfo = out))
}

perm.p = function(p.vector, p) {
    #to calculate permutation p value
    # p.vector is a vector of pvalues
    # p is a single p value
    # returned value is permutation pvalue
    p.v.new = c(p.vector, p)
    
    p.v.new = sort(p.v.new)
    
    p.i = which(p.v.new == p)
    p.i = ifelse(length(p.i) > 1, sort(p.i)[1], p.i)
    perm.p = p.i / length(p.v.new)
    
    return (list(
        perm.p = perm.p,
        total.length = length(p.v.new),
        rank = p.i
    ))
}

myscale = function (mat, scale = "row", na.rm = T)
{
    #used to scale matrix
    if (scale == "row") {
        x <-
            sweep(mat, 1L, rowMeans(mat, na.rm = na.rm), check.margin = FALSE)
        
        sx <- apply(x, 1L, sd, na.rm = na.rm)
        
        x <- sweep(x, 1L, sx, "/", check.margin = FALSE)
        
    }
    
    else if (scale == "column") {
        x <-
            sweep(mat, 2L, colMeans(mat, na.rm = na.rm), check.margin = FALSE)
        
        sx <- apply(x, 2L, sd, na.rm = na.rm)
        
        x <- sweep(x, 2L, sx, "/", check.margin = FALSE)
        
    }
    return (x)
}

showCols <-
    function(cl = colors(),
             bg = "grey",
             cex = 0.75,
             rot = 30) {
        m <- ceiling(sqrt(n <- length(cl)))
        
        length(cl) <- m * m
        
        cm <- matrix(cl, m)
        
        require("grid")
        
        grid.newpage()
        
        vp <- viewport(w = .92, h = .92)
        
        grid.rect(gp = gpar(fill = bg))
        
        grid.text(
            cm,
            x = col(cm) / m,
            y = rev(row(cm)) / m,
            rot = rot,
            vp = vp,
            gp = gpar(cex = cex, col = cm)
        )
    }

rf_impute = function (dat, response, if012 = T) {
    #dat should be transposed first
    #column: SNP/probe/...
    #row: samples
    #response: binominal factor
    #if012: if SNP genotyping data, then factor all data
    check_and_install_package("randomForest")
    
    library(randomForest)
    
    dup.i = which(duplicated(colnames(dat)))
    if (length(dup.i) > 0) {
        dat = dat[,-dup.i]
    }
    header = colnames(dat)
    
    test_response = factor(response)
    
    if (length(levels(test_response)) == 1) {
        set.seed(123)
        s.i = sample(1:length(test_response), 1)
        levels(test_response) = c(1, 2)
        test_response[s.i] = 2
    }
    trainData = data.frame(dat, check.names = F)
    
    if (if012) {
        for (i in 1:ncol(trainData)) {
            trainData[, i] = factor(trainData[, i], levels = c(0, 1, 2))
        }
    }
    if (nrow(trainData) != length(test_response))
        stop ("Length response is not equal to nrow of data matrix.")
    trainData$response = test_response
    
    data.imputed.f <- rfImpute(response ~ ., trainData)
    
    r.i = match("response", colnames(data.imputed.f))
    data.imputed = as.matrix(data.imputed.f[,-r.i])
    colnames(data.imputed) = header
    if (if012) {
        #return numeric values
        data.imputed.o = apply(data.imputed, 2, as.numeric)
    }
    return (data.imputed.o)
}

check_and_install_package = function (libNames) {
    installBioConPackage <- function (libName) {
        message (paste0("Package ", libName, " need to be installed.\n"))
        source("http://www.bioconductor.org/biocLite.R")
        biocLite(libName)
    }
    for (libName in libNames) {
        if (!(libName %in% installed.packages())) {
            installBioConPackage(libName)
            if ((libName %in% installed.packages())) {
                message (paste0(
                    "Package ",
                    libName,
                    " is successfully installed.\n"
                ))
            } else {
                message (paste0(
                    "Package ",
                    libName,
                    " is failed to be installed.\n"
                ))
            }
        }
    }
}

median.rm.na.numeric <- function(x) {
    # median numeric vector, treating NA's as 0 unless all NA the NA is returned
    #
    # Args:
    #   x: vector to be averaged
    #
    # Returns:
    #   resulting median
    #
    res <- if (all(is.na(x)))
        NA
    else
        median(x, na.rm = T)
    return(res)
}

mean.rm.na.numeric <- function(x) {
    # mean numeric vector, treating NA's as 0 unless all NA the NA is returned
    #
    # Args:
    #   x: vector to be averaged
    #
    # Returns:
    #   resulting mean
    #
    res <- if (all(is.na(x)))
        NA
    else
        mean(x, na.rm = T)
    return(res)
}

sum.rm.na <- function(x, ...)
    UseMethod('sum.rm.na')

min.rm.na.numeric <- function(x) {
    res <- if (all(is.na(x)))
        NA
    else
        min(x, na.rm = T)
    return(res)
}
max.rm.na.numeric <- function(x) {
    res <- if (all(is.na(x)))
        NA
    else
        max(x, na.rm = T)
    return(res)
}

sum.rm.na.numeric <- function(x) {
    # sums numeric vector, treating NA's as 0 unless all NA the NA is returned
    #
    # Args:
    #   x: vector to be summed
    #
    # Returns:
    #   resulting sum
    #
    res <- if (all(is.na(x)))
        NA
    else
        sum(x, na.rm = T)
    return(res)
}

sum.rm.na.logical <- function(x) {
    # sums logical vector, treating NA's as 0 unless all NA the NA is returned
    #
    # Args:
    #   x: vector to be summed
    #
    # Returns:
    #   resulting sum
    #
    res <- if (all(is.na(x)))
        NA
    else
        sum(x, na.rm = T)
    return(res)
}

sum.rm.na.data.frame <- function(x) {
    # sums rows of a data.frame, treating NA's as 0 unless all NA the NA is returned
    #
    # Args:
    #   x: data.frame to be summed
    #
    # Returns:
    #   vector of resulting sums
    #
    res <- apply(x, 1, sum.rm.na)
    return(res)
}

sum.rm.na.matrix <- function(x) {
    # sums rows of a matrix, treating NA's as 0 unless all NA then NA is returned
    #
    # Args:
    #   x: matrix to be summed
    #
    # Returns:
    #   vector of resulting sums
    #
    res <- apply(x, 1, sum.rm.na)
    return(res)
}

add.alpha <- function(col, alpha = 1) {
    if (missing(col)) {
        stop("Please provide a vector of colours.")
    }
    apply(sapply(col, col2rgb) / 255, 2, 		function(x)
        rgb(x[1], x[2], x[3], alpha = alpha))
}

pvadj = function (dat, pvcol)
    #dat: data matrix
    #pv: numeric vector of pvalue
    #pvcol: column of pvalue
    #RETURN a new datamatrix with additional bonferroni_adj, BH_fdr_adj, BY_adj columns
{
    pv = as.numeric(dat[, pvcol])
    
    bonferroni_adj = p.adjust(pv, method = "bonferroni")
    
    BH_fdr_adj = p.adjust(pv, method = "BH")
    
    BY_adj = p.adjust(pv, method = "BY")
    
    out = cbind(dat, bonferroni_adj, BH_fdr_adj, BY_adj)
    
    return (out)
    
}

add_phe = function (phe, phe_add, phe.id, phe_add.id, ...) {
    phe_add = phe_add[!is.na(phe_add[, phe_add.id]),]
    
    dup.i = which(duplicated(phe_add[,  phe_add.id]))
    
    if (length(dup.i > 0))
        phe_add = phe_add[-dup.i,]
    
    merged = unique(merge(
        phe,
        phe_add,
        by.x = phe.id,
        by.y = phe_add.id,
        all.x = T,
        sort = FALSE,
        ...
    ))
    
    return (merged)
}

binomial_continous = function (x) {
    med = median (x, na.rm = T)
    
    l.i = which(x < med)
    
    h.i = which(x >= med)
    
    x[l.i] = 0
    
    x[h.i] = 1
    
    return (x)
}

my_rowname = function (phe, rownameid = "microarrayid") {
    phe = phe[!is.na(phe[, rownameid]),]
    dup.i = which(duplicated(phe[, rownameid]))
    
    if (length(dup.i > 0))
        phe = phe[-dup.i,]
    rownames(phe) = phe[, rownameid]
    return (phe)
    
}

get_phenotype <-
    function (source_phe,
              dest_name,
              limit_vector,
              source_limit_cond_colname) {
        #source_phe: 从这里取数据，必须有header name (colname)，有source_phe，有source_limit_cond_colname列
        #dest_name: source_phe中需要有这一列，目标数据的colname
        #limit_vector: 对所取数据的内容和排序的限定，通过另一不同的列完成，要求本列必须无重复，可以作为rownames
        #source_limit_cond_colname: 满足limit_vector的列名colname
        
        ifall = logical()
        missed_rownum = c()
        #limit_vector = as.character(limit_vector)
        #source_phe[,source_limit_cond_colname] = as.character(source_phe[,source_limit_cond_colname])
        pheno = rep(NA, times = length(limit_vector))
        na.filter = which(is.na(source_phe[, source_limit_cond_colname]))
        cat("NA:", na.filter, "\n", sep = "")
        
        if (length(na.filter > 0))
            source_phe = source_phe[-na.filter,]
        row.names(source_phe) = source_phe[, source_limit_cond_colname]
        if (all(limit_vector %in% source_phe[, source_limit_cond_colname])) {
            ifall = TRUE
        } else {
            ifall = FALSE
            missed_rownum = setdiff(limit_vector, source_phe[, source_limit_cond_colname])
        }
        common_po = which(limit_vector %in% source_phe[, source_limit_cond_colname])
        common = as.character(limit_vector[common_po])
        pheno[common_po] = source_phe[common, dest_name]
        ret = list(ifall = ifall,
                   pheno = pheno,
                   missed_rownum = missed_rownum)
        return (ret)
    }

empty.num = function(x) {
    return (sum(is.na(x) | x == "" | is.null(x), na.rm = T))
    
}

na.num = function(x) {
    return (sum(is.na(x), na.rm = T))
    
}

nonna.num = function(x) {
    return (sum(!is.na(x), na.rm = T))
    
}

merge2col = function(dat, colx, coly) {
    #dat is a data.frame
    #colx is a col name in dat
    #coly is a col name in dat
    #colx and coly supposed to be same data but with diffent number of elements, usually came from merge function
    colx.i = match(colx, names(dat))
    
    coly.i = match(coly, names(dat))
    
    if (is.na(colx.i) |
        is.na(coly.i))
        stop (paste0(colx.i, " or ", coly.i, " does not exist in dat. "))
    
    na.i = which(is.na(dat[, colx]))
    
    if (length(na.i) == 0) {
        cat ("No NA value in ", colx, " column. ", "\n")
        
        new.name = gsub("\\.x", "", colx)
        
        new.name = gsub("\\.y", "", new.name)
        
        names(dat)[colx.i] = new.name
        
        dat = dat[,-coly.i]
        return (dat)
        
    }
    l = length(na.i)
    
    l.add = sum(!(is.na(dat[na.i, coly]) |
                      is.null(dat[na.i, coly]) |
                      dat[na.i, coly] == ""))
    
    dd = na.omit(dat[, c(colx, coly)])
    
    l.mismatch = sum(!(dd[, 1] == dd[, 2]))
    
    cat (
        "Total NA length: ",
        l,
        " || effective adding count: ",
        l.add,
        " || mismatch count: ",
        l.mismatch,
        "\n",
        sep = ""
    )
    
    if (l.add == 0) {
        if (l.mismatch != 0) {
            cat ("There are mismatches!!! Having stopped merging process. ",
                 "\n",
                 sep = "")
            
            diff.i = which(!(dd[, 1] == dd[, 2]))
            print (dd[diff.i,])
            
        }
        cat ("\n", "No non-NA value can be added", "\n", sep = "")
        
        new.name = gsub("\\.x", "", colx)
        
        new.name = gsub("\\.y", "", new.name)
        
        names(dat)[colx.i] = new.name
        
        dat = dat[,-coly.i]
        return (dat)
        
    }
    if (l.mismatch != 0) {
        cat ("There are mismatches!!! Having stopped merging process. ",
             "\n",
             sep = "")
        
        diff.i = which(!(dd[, 1] == dd[, 2]))
        print (dd[diff.i,])
        
        return (dat)
        
    }
    dat[na.i, colx] =  dat[na.i, coly]
    
    new.name = gsub("\\.x", "", colx)
    
    new.name = gsub("\\.y", "", new.name)
    
    names(dat)[colx.i] = new.name
    
    dat = dat[,-coly.i]
    return(dat)
    
}

merge_all_col = function (x) {
    header = names(x)
    
    x.i = grep("\\.x", header)
    
    y.i = grep("\\.y", header)
    
    if (length(x.i) != length(y.i))
        stop (".y length is not equal to .x length.")
    if (length(x.i) == 0 | length(y.i) == 0) {
        cat ("No need to merge. Neither .x nor .y col.", "\n")
        
        return (x)
        
    }
    for (i in x.i) {
        ori.n = header[i]
        
        new.n = gsub("\\.x", "", ori.n)
        
        new.n = paste0(new.n, ".y")
        
        cat (ori.n, new.n, "\n", sep = "\t")
        
        x = merge2col(x, ori.n, new.n)
        
    }
    return (x)
    
}

check_phe = function (new_d) {
    str(new_d)
    apply(new_d, 2, na.num)
    #	apply(new_d, 2, nonna.num)
}

####function to plot pca
pcaCharts <- function(x, n = 50) {
    x.var <- x$sdev[1:n] ^ 2
    x.pvar <- x.var / sum(x.var)
    print("proportions of variance:")
    print(x.pvar)
    
    par(mfrow = c(2, 2))
    plot(100 * x.pvar,
         xlab = "Principal component",
         ylab = "Proportion of variance explained (%)",
         type = 'b')
    plot(
        cumsum(x.pvar),
        xlab = "Principal component",
        ylab = "Cumulative Proportion of variance explained",
        ylim = c(0, 1),
        type = 'b'
    )
    screeplot(x, npcs = min(n, length(x$sdev)), main = "")
    screeplot(x,
              type = "l",
              npcs = min(n, length(x$sdev)),
              main = "")
    par(mfrow = c(1, 1))
    return(x.pvar)
    
}

split_corr_symbol = function(x, num = 1) {
    #used to split IFI35|ILMN_1745374|cg22281505
    #num = 1 is for symbol, e.g. IFI35
    #num = 2 is for expr probe, e.g. ILMN_1745374
    #num = 3 is for methy probe, e.g. cg22281505
    ret = x
    
    need.i = grep("|", x)
    
    for (i in need.i) {
        sym = x[i]
        
        (gs = unlist(strsplit(sym, "|", fixed = T)))
        
        ret[i] = gs[num]
    }
    return(ret)
}

gene_symbol_trim = function (x, split_symbol = ";") {
    #for triming the ";", and return 1st sym;
    ret = x
    
    need.i = grep (split_symbol, x)
    
    for (i in need.i) {
        sym = x[i]
        
        gs = unlist(strsplit(sym, split_symbol, fixed = T))
        
        ret[i] = gs[1]
        
    }
    return (ret)
    
}

mysubset = function (d,
                     col.d = 1,
                     m,
                     CPUnum = 20,
                     reverse = F)
    #for getting sub-set from a large data frame
    #d: data frame
    #col.d: colnames/colnumber of d, which will be used to match with m
    #m: destination values match with d[,col.d]
    #reverse: choose or choose reverse
{
    library(doParallel)
    registerDoParallel(cores = CPUnum)
    n = nrow(d)
    blocksize = as.integer(n / (CPUnum + 1))
    pos = seq(1, n, blocksize)
    pos[length(pos) + 1] = n + 1
    #original version is not correct.
    pos
    block_num = length(pos) - 1
    cat ("Block number: ", block_num, "\n")
    #from bumphunter script;
    #workers <- getDoParWorkers()
    #chunksize <- ceiling(n / workers)
    output <- foreach (j = 1:block_num, .combine = rbind) %dopar%
    {
        start = pos[j]
        end = pos[j + 1] - 1
        temp = d[start:end,]
        #m.i = match(m, temp[,col.d], nomatch=0);
        if (reverse) {
            m.i = which(!(temp[, col.d] %in% m))
            
        } else {
            m.i = which(temp[, col.d] %in% m)
        }
        if (length(m.i) > 0)
        {
            out = temp[m.i, ]
            
        } else {
            out = c()
            
        }
        return (out)
    }
    return (output)
    
}


get_H = function (x)
    #used to fix the breaks, xlim, ylim of two hist figures.
    #x is producted by merging two numeric verctors with same lengths.
{
    l = length(x)
    
    l1 = 1:as.integer(l / 2)
    
    l2 = (l / 2 + 1):l
    
    H1 =  hist(x[l1], plot = FALSE)
    
    H2 =  hist(x[l2], plot = FALSE)
    
    H = c()
    
    breaks = c(H1$breaks, H2$breaks)
    
    H$breaks = seq(
        from = min(breaks, na.rm = T),
        to = max(breaks, na.rm = T),
        length.out = 15
    )
    
    H1 =  hist(x[l1], plot = FALSE, breaks = H$breaks)
    
    H2 =  hist(x[l2], plot = FALSE, breaks = H$breaks)
    
    H$counts = sort(unique(c(H1$counts, H2$counts)))
    
    return (H)
    
}

draw_pca_without_color = function (p.pca,
                                   cex = 1.5,
                                   cex.lab = 1.2,
                                   main = "PCA")
{
    if (!("ggbiplot" %in% installed.packages())) {
        library(devtools)
        install_github("vqv/ggbiplot")
    }
    library(ggbiplot)
    library("scatterplot3d")
    
    plot(p.pca, type = "l")
    #    print (p.pca)
    
    #PC1:PC2
    g <- ggbiplot(
        p.pca,
        obs.scale = 1,
        choices = 1:2,
        #groups = wine.class,
        # ellipse = TRUE,
        # circle = TRUE,
        #labels = F,
        var.axes = F,
        var.scale = 1,
        cex = cex,
        cex.axis = cex.lab,
        cex.lab = cex.lab
    )
    g <- g + scale_color_discrete(name = '')
    g <- g + theme(legend.direction = 'horizontal',
                   legend.position = 'top')
    print(g)
    
    #PC1:PC3
    g <- ggbiplot(
        p.pca,
        obs.scale = 1,
        choices = c(1, 3),
        #groups = wine.class,
        # ellipse = TRUE,
        # circle = TRUE,
        #labels = F,
        var.axes = F,
        var.scale = 1,
        cex = cex,
        cex.axis = cex.lab,
        cex.lab = cex.lab
    )
    g <- g + scale_color_discrete(name = '')
    g <- g + theme(legend.direction = 'horizontal',
                   legend.position = 'top')
    print(g)
    
    #PC2:PC3
    g <- ggbiplot(
        p.pca,
        obs.scale = 1,
        choices = 2:3,
        #groups = wine.class,
        # ellipse = TRUE,
        # circle = TRUE,
        #labels = F,
        var.axes = F,
        var.scale = 1,
        cex = cex,
        cex.axis = cex.lab,
        cex.lab = cex.lab
    )
    g <- g + scale_color_discrete(name = '')
    g <- g + theme(legend.direction = 'horizontal',
                   legend.position = 'top')
    print(g)
    
    pairs(p.pca$x[, 1:3])
    s3d <- scatterplot3d(
        p.pca$x[, 1:3],
        type = "p",
        angle = 35,
        cex = cex,
        cex.axis = cex.lab,
        cex.lab = cex.lab
    )
}

draw_pca_with_color = function (pca,
                                type,
                                cex = 1.5,
                                cex.lab = 1.2,
                                legend.title = "Type",
                                legend.char = legend.char,
                                main = "PCA")
    #pca is prcomp output
    #type is binary factor
{
    n = ifelse(ncol(pca$x) > 50, 50, ncol(pca$x))
    par(mar = c(5, 5, 4, 2), mgp = c(3, 1, 0))
    
    perc.import = pcaCharts(pca, n)
    
    cols.all = rainbow(10, alpha = 0.7)
    cols = c(cols.all[2], cols.all[7])
    library(car)
    library(RColorBrewer)
    
    type.num = ifelse(nlevels(type) > 6, 6, nlevels(type))
    cols1 <- brewer.pal(8, "Set1")[1:type.num]
    cols = rev(cols1)
    pchs = c(19, 17, 15, 18, 16, 20)[1:type.num]
    
    scatterplot(
        pca$x[, 2] ~ pca$x[, 1] |
            type,
        #data = data,
        pch = pchs,
        ellipse = T,
        col = cols,
        lwd = 2,
        reg.line = F,
        boxplots = "xy",
        legend.title = legend.title,
        main = main,
        xlab = paste0("PC1 ", " (", round(perc.import[1] * 100, 0), "%)"),
        ylab = paste0("PC2 ", " (", round(perc.import[2] * 100, 0), "%)"),
        cex = cex,
        cex.axis = cex.lab,
        cex.lab = cex.lab,
        smooth = F
    )
    
    scatterplot(
        pca$x[, 3] ~ pca$x[, 1] |
            type,
        #data = data,
        #pch = 19,
        pch = pchs,
        ellipse = T,
        col = cols,
        lwd = 2,
        reg.line = F,
        #legend.title = "",
        boxplots = "xy",
        legend.title = legend.title,
        main = main,
        xlab = paste0("PC1 ", " (", round(perc.import[1] * 100, 0), "%)"),
        ylab = paste0("PC3 ", " (", round(perc.import[3] * 100, 0), "%)"),
        cex = cex,
        cex.axis = cex.lab,
        cex.lab = cex.lab,
        smooth = F
    )
    
    scatterplot(
        pca$x[, 3] ~ pca$x[, 2] |
            type,
        #data = data,
        #pch = 19,
        pch = pchs,
        ellipse = T,
        col = cols,
        lwd = 2,
        reg.line = F,
        #legend.title = "",
        boxplots = "xy",
        legend.title = legend.title,
        main = main,
        xlab = paste0("PC2 ", " (", round(perc.import[2] * 100, 0), "%)"),
        ylab = paste0("PC3 ", " (", round(perc.import[3] * 100, 0), "%)"),
        cex = cex,
        cex.axis = cex.lab,
        cex.lab = cex.lab,
        smooth = F
    )
    
    pairs(pca$x[, 1:3], col = cols[type])
    
    data = data.frame(
        PC1 = pca$x[, 1],
        PC2 = pca$x[, 2],
        PC3 = pca$x[, 3],
        type = type
    )
    scatterplotMatrix(
        ~ PC1 +
            PC2 +
            PC3 | type,
        data = data,
        pch = pchs,
        ellipse = T,
        smooth = F,
        col = cols,
        lwd = 2,
        reg.line = F,
        #legend.title = "",
        boxplots = "xy",
        legend.title = legend.title,
        main = main,
    )
    
    s3d <-
        scatterplot3d(
            pca$x[, 1:3],
            type = "p",
            angle = 35,
            color = cols[type],
            main = main,
            cex = cex,
            cex.axis = cex.lab,
            cex.lab = cex.lab
        )
    
    legend(
        "topleft",
        legend = legend.char,
        col = cols,
        pch = 19,
        cex = cex
    )
    
}

r.table = function (in_f,
                    header = T,
                    row.names = NULL,
                    sep = "auto",
                    check.names = F,
                    verbose = F,
                    ...)
    #use data.table to read large file
    #tab delimited
{
    library(data.table)
    
    dat = fread(
        in_f,
        header = header,
        sep = sep,
        check.names = check.names,
        verbose = verbose,
        ...
    )
    
    dat = data.frame(dat, row.names = row.names, check.names = check.names)
    
    return (dat)
    
}
#myfread = r.table


w.table = function (out,
                    file,
                    col.names = T,
                    row.names = F,
                    col1name = "probe",
                    quote = F,
                    append = F,
                    sep = "\t",
                    ...)
{
    if (row.names) {
        if (col.names) {
            cat (
                col1name,
                colnames(out),
                file = file,
                sep = sep,
                append = append
            )
            cat ("\n", file = file, append = T)
        }
        write.table(
            out,
            file = file,
            sep = sep,
            col.names = F,
            row.names = T,
            append = T,
            quote = quote,
            ...
        )
        
    } else {
        write.table(
            out,
            file = file,
            sep = sep,
            col.names = col.names,
            row.names = row.names,
            append = append,
            quote = quote,
            ...
        )
    }
}

#another convenient name of function

glmnet.cv <-
    function (data,
              class,
              family = "gaussian",
              s = 0.05,
              CPUnum = 20)
    {
        library(glmnet)
        
        data <- as.matrix(data)
        if (any(is.na(data)) || any(is.na(class)))
            stop("no missing values are allowed")
        p <- ncol(data)
        if (length(class) != p)
            stop("'data' and 'class' have different lengths")
        
        prediction <- vector()
        
        library(doParallel)
        
        registerDoParallel(cores = CPUnum)
        
        output <-
            foreach (j = 1:length(colnames(data)), .combine = rbind) %dopar%
            {
                call <- t(subset(data, select = c(-j)))
                cla <- class[-j]
                
                leftSamp <- t(subset(data, select = c(j)))
                trueCla <- class[j]
                
                model <- svm(call, cla)
                pred <- as.numeric(predict(model, leftSamp))
                model <- glmnet(data.t, class, family = family)
                pred <-
                    as.numeric(predict(model, leftSamp, type = "class", s = s))
                pred
                #prediction[j] <- pred
            }
        output
        
    }

svm.cv <- function (data, class, CPUnum = 20)
{
    require('e1071')
    require("caret")
    data <- as.matrix(t(data))
    if (any(is.na(data)) || any(is.na(class)))
        stop("no missing values are allowed")
    p <- ncol(data)
    if (length(class) != p)
        stop("'data' and 'class' have different lengths")
    
    prediction <- vector()
    
    library(doParallel)
    
    registerDoParallel(cores = CPUnum)
    
    prediction <-
        foreach (j = 1:length(colnames(data)), .combine = rbind) %dopar%
        {
            #for (j in 1:length(colnames(data))) {
            call <- t(subset(data, select = c(-j)))
            cla <- class[-j]
            
            leftSamp <- t(subset(data, select = c(j)))
            model <- svm(call, cla)
            #pred <- as.numeric(predict(model, leftSamp))
            pred <- predict(model, leftSamp)
            pred = as.character(pred)
            trueCla <- as.character(class[j])
            c(pred, trueCla)
        }
    colnames(prediction) = c("Pred", "Class")
    model <- svm(t(data), class, probability = T)
    list(
        prediction = prediction,
        model = model,
        confusionMatrix = confusionMatrix(prediction[, 1], prediction[, 2])
    )
    
}

nnet.cv <- function (data, class, CPUnum = 20, MaxNWts)
{
    #data <- data.frame(data)
    require('nnet')
    require("caret")
    if (missing(MaxNWts))
        MaxNWts = 3 * ncol(data)
    data <- as.matrix(t(data))
    if (any(is.na(data)) || any(is.na(class)))
        stop("no missing values are allowed")
    p <- ncol(data)
    if (length(class) != p)
        stop("'data' and 'class' have different lengths")
    
    prediction <- vector()
    library(doParallel)
    
    registerDoParallel(cores = CPUnum)
    
    model <-
        nnet(
            class ~ .,
            data = t(data),
            size = 2,
            rang = 0.1,
            decay = 5e-4,
            maxit = 200,
            trace = FALSE,
            probability = T,
            importance = TRUE,
            MaxNWts = MaxNWts
        )
    
    #for too many predictors, the running time is too long. so, only 2000 predictor matrix is allowed for leave one out cycle.
    if (nrow(data) < 2000) {
        prediction <-
            foreach (j = 1:length(colnames(data)), .combine = rbind) %dopar%
            {
                call <- t(subset(data, select = c(-j)))
                cla <- class[-j]
                leftSamp <- t(subset(data, select = c(j)))
                model <-
                    nnet(
                        cla ~ .,
                        data = call,
                        size = 2,
                        rang = 0.1,
                        decay = 5e-4,
                        maxit = 200,
                        trace = FALSE,
                        MaxNWts = MaxNWts
                    )
                pred <- predict(model, leftSamp, type = "class")
                pred = as.character(pred)
                trueCla <- as.character(class[j])
                c(pred, trueCla)
            }
    } else {
        pred = predict(model, newdata = t(data), type = "class")
        prediction = cbind(pred, as.character(class))
    }
    colnames(prediction) = c("Pred", "Class")
    head(prediction)
    list(
        prediction = prediction,
        model = model,
        confusionMatrix = confusionMatrix(prediction[, 1], prediction[, 2])
    )
}

nb.cv <- function (data,
                   class,
                   CPUnum = 20,
                   ntree = 500)
{
    require('e1071')
    require("caret")
    data <- as.matrix(t(data))
    if (any(is.na(data)) || any(is.na(class)))
        stop("no missing values are allowed")
    p <- ncol(data)
    if (length(class) != p)
        stop("'data' and 'class' have different lengths")
    
    prediction <- vector()
    
    library(doParallel)
    
    registerDoParallel(cores = CPUnum)
    
    prediction <-
        foreach (j = 1:length(colnames(data)), .combine = rbind) %dopar%
        {
            #for (j in 1:length(colnames(data))) {
            call <- t(subset(data, select = c(-j)))
            cla <- class[-j]
            leftSamp <- t(subset(data, select = c(j)))
            model <- naiveBayes(call, cla)
            pred <- predict(model, leftSamp)
            pred = as.character(pred)
            trueCla <- as.character(class[j])
            c(pred, trueCla)
        }
    colnames(prediction) = c("Pred", "Class")
    model <- naiveBayes(t(data), class)
    list(
        prediction = prediction,
        model = model,
        confusionMatrix = confusionMatrix(prediction[, 1], prediction[, 2])
    )
}

rf.cv <- function (data,
                   class,
                   CPUnum = 20,
                   ntree = 500,
                   ...)
{
    require(randomForest)
    require("caret")
    data <- as.matrix(t(data))
    if (any(is.na(data)) || any(is.na(class)))
        stop("no missing values are allowed")
    p <- ncol(data)
    if (length(class) != p)
        stop("'data' and 'class' have different lengths")
    
    prediction <- vector()
    library(doParallel)
    
    registerDoParallel(cores = CPUnum)
    
    prediction <-
        foreach (j = 1:length(colnames(data)), .combine = rbind) %dopar%
        {
            #for (j in 1:length(colnames(data))) {
            call <- t(subset(data, select = c(-j)))
            cla <- class[-j]
            leftSamp <- t(subset(data, select = c(j)))
            model <-
                randomForest(call, cla, ntree = ntree, importance = TRUE)
            pred <- predict(model, leftSamp, type = "response")
            pred = as.character(pred)
            trueCla <- as.character(class[j])
            c(pred, trueCla)
        }
    colnames(prediction) = c("Pred", "Class")
    model <-
        randomForest(t(data),
                     class,
                     ntree = ntree,
                     importance = TRUE,
                     ...)
    list(
        prediction = prediction,
        model = model,
        confusionMatrix = confusionMatrix(prediction[, 1], prediction[, 2])
    )
}


my_pred_plot <-
    function(Prediction,
             Outcome,
             threshold,
             title = "",
             xlab = "Outcome",
             ylab = "Prediction",
             alpha = 0.8,
             positive = NULL,
             reverse = F,
             #if < threshold is positive
             ...) {
        df <- data.frame(cbind(Prediction, Outcome))
        df$Outcome = as.factor(Outcome)
        
        if (!is.character(positive) &
            !is.null(positive))
            stop("positive argument must be character")
        
        classLevels <- levels(df$Outcome)
        numLevels <- length(classLevels)
        if (numLevels < 2)
            stop("there must be at least 2 factors levels in the data")
        if (numLevels == 2 &
            is.null(positive))
            positive <- levels(df$Outcome)[2]
        negative <- classLevels[!(classLevels %in% positive)]
        print (table(Outcome))
        message (paste0("Positive: ", positive, "; Negative: ", negative))
        
        #	levels(df$Outcome) = c(0, 1);
        
        v <- rep(NA, nrow(df))
        
        v <-
            ifelse(df$Prediction >= threshold &
                       #df$Outcome == levels(df$Outcome)[2],
                       df$Outcome == positive,
                   "TP",
                   v)
        
        v <-
            ifelse(df$Prediction >= threshold &
                       #df$Outcome == levels(df$Outcome)[1],
                       df$Outcome == negative,
                   "FP",
                   v)
        
        v <-
            ifelse(df$Prediction < threshold  &
                       #df$Outcome == levels(df$Outcome)[2],
                       df$Outcome == positive,
                   "FN",
                   v)
        
        v <-
            ifelse(df$Prediction < threshold  &
                       #df$Outcome == levels(df$Outcome)[1],
                       df$Outcome == negative,
                   "TN",
                   v)
        
        df$pred_type <- v
        
        #if positive in level[1]
        #if (positive == levels(df$Outcome)[1])  {
        if (reverse) {
            df$pred_type[which(v == "FN")] = "TP"
            df$pred_type[which(v == "FP")] = "TN"
            df$pred_type[which(v == "TP")] = "FN"
            df$pred_type[which(v == "TN")] = "FP"
        }
        
        library(ggplot2)
        
        print(
            ggplot(data = df, aes(x = Outcome, y = Prediction)) +
                labs(x = xlab, y = ylab) +
                geom_violin(fill = rgb(1, 1, 1, alpha = alpha), color = NA) +
                geom_jitter(aes(color = pred_type), alpha = alpha) +
                geom_hline(
                    yintercept = threshold,
                    color = "red",
                    alpha = alpha
                ) +
                scale_color_discrete(name = "type") +
                labs(title = sprintf(title, threshold))
        )
        
    }

my_roc = function(outcome, prediction, title = "", ...)
{
    library(pROC)
    
    rocobj <- plot.roc(
        outcome,
        prediction,
        main = title,
        percent = TRUE,
        ci = TRUE,
        # compute AUC (of AUC by default)
        print.auc = TRUE
    )
    # print the AUC (will contain the CI)
    ciobj <- ci.se(rocobj, # CI of sensitivity
                   specificities = seq(0, 100, 5))
    # over a select set of specificities
    plot(ciobj, type = "shape", col = "#1c61b6AA", ...)
    # plot as a blue shape
}

prediction_ROC = function (data.training,
                           class,
                           data.test,
                           class.t,
                           #usually 0,1 level factor
                           pdf = NULL,
                           threshold = NULL,
                           threads = 20,
                           svm = T,
                           rf = T,
                           nnet = T,
                           glmnet = T,
                           xgboost = T,
                           dl = T,
                           positive = NULL,
                           #DF: 1
                           reverse = F,
                           #if < threshold is positive
                           ...)
#used to build model using data.training, and make prediction using data.test.
#pdf: output pdf file name, or null
#threshold, 1.5 for case/control data, otherwise mean?
#class: outcome of training set, can be contenous or two levels' factor
#class.t: outcome of test set, must be a factor with two levels
#threads: deep learning (h2o) threads
#currently including RF, SVM, NNET, GLMNET, deep learning
{
    if (!is.null(pdf)) {
        pdf (pdf, 6, 6, family = "ArialMT")
    }
    
    outcome = as.factor(class.t)
    
    auc.out = list()
    
    needed_packages = c(
        "pROC",
        "genalg",
        "MASS",
        "class",
        "nnet",
        "pls",
        "e1071",
        "limma",
        "randomForest",
        "xgboost",
        "glmnet"
    )
    
    for (p in needed_packages) {
        check_and_install_package(p)
    }
    library(pROC)
    library(genalg)
    library(MASS)
    library(class)
    library(nnet)
    library(pls)
    library('e1071')
    library(limma)
    library(randomForest)
    library(glmnet)
    
    data.test.t = data.test
    data.t = data.training
    
    #levels(class.t) = c(1, 2)
    
    family = ifelse (is.factor(class) &
                         length(levels(class)) == 2,
                     "binomial",
                     "gaussian")
    
    ##xgboost
    if (xgboost) {
        message ("Processing xgboost ... \n")
        require(xgboost)
        dtrain <- xgb.DMatrix(data = data.t, label = class)
        dtest <- xgb.DMatrix(data = data.test.t, label = class.t)
        watchlist <- list(train = dtrain, test = dtest)
        model.xg <- xgb.train(
            data = dtrain,
            watchlist = watchlist,
            nthread = threads,
            nround = 2,
            max.depth = 2
            #objective = "reg:linear"
            #objective = "binary:logistic"
        )
        pred.xg <- as.numeric(predict(model.xg, data.test.t))
        if (is.null(threshold)) {
            threshold = ifelse(family == "binomial", 1.5, mean(pred.xg, na.rm = T))
        }
        
        if (!is.null(pdf)) {
            my_pred_plot(
                Prediction = pred.xg,
                Outcome = class.t,
                title = "xgboost prediction",
                threshold = threshold,
                positive = positive,
                reverse = reverse,
                ...
            )
            
            my_roc(
                outcome = class.t,
                prediction = pred.xg,
                title = "ROC of xgboost prediction"
            )
        }
        
        roc.obj = roc(class.t, pred.xg, auc = TRUE)
        
        auc = as.numeric(roc.obj$auc)
        
        cat (" AUC = ", auc, "\n")
        #if (positive == levels(outcome)[2]) {
        if (!reverse) {
            pred.xg.binomial = as.numeric(pred.xg >= threshold)
        } else {
            pred.xg.binomial = as.numeric(pred.xg < threshold)
        }
        
        cm = confusionMatrix(pred.xg.binomial, class.t,
                             positive = positive,
                             ...)
        auc.out$auc$xg =  auc
        auc.out$cm$xg =  cm
        
    }
    
    ##SVM
    if (svm) {
        message ("Processing SVM ... \n")
        
        model.svm <- svm(data.t, class)
        pred.svm <- as.numeric(predict(model.svm, data.test.t))
        sum(pred.svm == class.t) / length(class.t)
        
        #threshold = ifelse(family == "binomial", 1.5, mean(pred.svm, na.rm = T))
        if (is.null(threshold)) {
            threshold = ifelse(family == "binomial", 1.5, mean(pred.svm, na.rm = T))
        }
        
        if (!is.null(pdf)) {
            my_pred_plot(
                Prediction = pred.svm,
                Outcome = class.t,
                title = "SVM prediction",
                threshold = threshold,
                positive = positive,
                reverse = reverse
            )
            
            my_roc(
                outcome = class.t,
                prediction = pred.svm,
                cex.lab = 2,
                title = "ROC of SVM prediction"
            )
        }
        
        roc.obj = roc(class.t, pred.svm, auc = TRUE)
        
        auc = as.numeric(roc.obj$auc)
        
        auc.svm = auc
        
        cat (" AUC = ", auc, "\n")
        
        #auc.out$svm.auc =  auc
        #pred.binomial = as.numeric(pred.svm > threshold)
        #if (positive == levels(outcome)[2]) {
        if (!reverse) {
            pred.binomial = as.numeric(pred.svm >= threshold)
        } else {
            pred.binomial = as.numeric(pred.svm < threshold)
        }
        cm = confusionMatrix(pred.binomial, class.t,
                             positive = positive,
                             ...)
        auc.out$auc$svm =  auc
        auc.out$cm$svm =  cm
        
    }
    
    ##NNET
    if (nnet) {
        message ("Processing NNET ... \n")
        
        model.nnet <-
            nnet(
                class ~ .,
                data = data.t,
                size = 2,
                rang = 0.1,
                decay = 5e-4,
                maxit = 200,
                trace = FALSE
            )
        
        pred.nnet <- as.numeric(predict(model.nnet, data.test.t))
        
        
        #threshold = mean(pred.nnet, na.rm = T)
        if (is.null(threshold)) {
            threshold = ifelse(family == "binomial", 1.5, mean(pred.nnet, na.rm = T))
        }
        threshold.nnet = threshold
        
        if (!is.null(pdf)) {
            my_pred_plot(
                Prediction = pred.nnet,
                Outcome = class.t,
                title = "NNET prediction",
                threshold = threshold.nnet,
                positive = positive,
                reverse = reverse,
                ...
            )
            
            my_roc(
                outcome = class.t,
                prediction = pred.nnet,
                title = "ROC of NNET prediction"
            )
        }
        
        roc.obj = roc(class.t, pred.nnet, auc = TRUE)
        
        auc = as.numeric(roc.obj$auc)
        
        cat (" AUC = ", auc, "\n")
        
        #auc.out$nnet.auc =  auc
        #pred.binomial = as.numeric(pred.nnet > threshold)
        #if (positive == levels(outcome)[2]) {
        if (!reverse) {
            pred.binomial = as.numeric(pred.nnet >= threshold)
        } else {
            pred.binomial = as.numeric(pred.nnet < threshold)
        }
        cm = confusionMatrix(pred.binomial, class.t,
                             positive = positive,
                             ...)
        auc.out$auc$nnet =  auc
        auc.out$cm$nnet =  cm
        
    }
    
    ##RF
    if (rf) {
        message ("Processing RF ... \n")
        
        model.rf <-
            randomForest(
                data.t,
                class,
                ntree = 500,
                importance = TRUE,
                mtry = floor(sqrt(ncol(data.t)))
            )
        
        pred.rf <- as.numeric(predict(model.rf, data.test.t))
        
        sum(pred.rf == class.t) / length(class.t)
        
        if (is.null(threshold)) {
            threshold = ifelse(family == "binomial", 1.5, mean(pred.rf, na.rm = T))
        }
        #threshold = mean(pred.rf, na.rm = T)
        
        if (!is.null(pdf)) {
            my_pred_plot(
                Prediction = pred.rf,
                Outcome = class.t,
                title = "RF prediction",
                threshold = threshold,
                positive = positive,
                reverse = reverse,
                ...
            )
            
            my_roc(
                outcome = class.t,
                prediction = pred.rf,
                title = "ROC of RF prediction"
            )
        }
        
        roc.obj = roc(class.t, pred.rf, auc = TRUE)
        
        auc = as.numeric(roc.obj$auc)
        
        auc.rf = auc
        
        cat (" AUC = ", auc, "\n")
        
        #auc.out$rf.auc =  auc
        #pred.binomial = as.numeric(pred.rf > threshold)
        #if (positive == levels(outcome)[2]) {
        if (!reverse) {
            pred.binomial = as.numeric(pred.rf >= threshold)
        } else {
            pred.binomial = as.numeric(pred.rf < threshold)
        }
        cm = confusionMatrix(pred.binomial, class.t,
                             positive = positive,
                             ...)
        auc.out$auc$rf =  auc
        auc.out$cm$rf =  cm
        
    }
    
    ##glmnet
    if (glmnet) {
        message ("Processing glmnet ... \n")
        
        glmnet.fit = glmnet(data.t, class, family = family)
        
        pred.glmnet = predict(glmnet.fit,
                              data.test.t,
                              type = "class",
                              s = c(0.05, 0.01))
        
        pred.glmnet = apply(pred.glmnet, 2, as.numeric)
        sum(pred.glmnet[, 1] == class.t) / nrow(pred.glmnet)
        
        sum(pred.glmnet[, 2] == class.t) / nrow(pred.glmnet)
        
        #threshold = mean(pred.glmnet[, 1], na.rm = T)
        if (is.null(threshold)) {
            threshold = ifelse(family == "binomial",
                               1.5,
                               mean(pred.glmnet[, 1], na.rm = T))
        }
        
        if (!is.null(pdf)) {
            my_pred_plot(
                Prediction = pred.glmnet[, 1],
                Outcome = class.t,
                title = "glmnet prediction, s = 0.05",
                threshold = threshold,
                ...
            )
            
            my_roc(
                outcome = class.t,
                prediction = pred.glmnet[, 1],
                title = "ROC of glmnet prediction, s = 0.05"
            )
        }
        
        #threshold = mean(pred.glmnet[, 2], na.rm = T)
        if (is.null(threshold)) {
            threshold = ifelse(family == "binomial",
                               1.5,
                               mean(pred.glmnet[, 2], na.rm = T))
        }
        
        if (!is.null(pdf)) {
            my_pred_plot(
                Prediction = pred.glmnet[, 2],
                Outcome = class.t,
                title = "glmnet prediction, s = 0.01",
                threshold = threshold,
                ...
            )
            
            my_roc(
                outcome = class.t,
                prediction = pred.glmnet[, 2],
                title = "ROC of glmnet prediction, s = 0.01"
            )
        }
        
        roc.obj = roc(class.t, pred.glmnet[, 1], auc = TRUE)
        
        auc = as.numeric(roc.obj$auc)
        
        auc.glmnet005 = auc
        
        cat (" s=0.05 AUC = ", auc, "\n")
        
        auc.out$glmnet.s005 =  auc
        
        roc.obj = roc(class.t, pred.glmnet[, 2], auc = TRUE)
        
        auc = as.numeric(roc.obj$auc)
        
        auc.glmnet001 = auc
        
        cat (" s=0.01 AUC = ", auc, "\n")
        
        pred.binomial = as.numeric(pred.glmnet[, 2] > threshold)
        cm = confusionMatrix(pred.binomial, class.t, ...)
        auc.out$auc$glmnet001 =  auc.glmnet001
        auc.out$cm$glmnet001 =  cm
        #auc.out$glmnet.s001 =  auc
        pred.binomial = as.numeric(pred.glmnet[, 1] > threshold)
        cm = confusionMatrix(pred.binomial, class.t, ...)
        auc.out$auc$glmnet005 =  auc.glmnet005
        auc.out$cm$glmnet005 =  cm
        
    }
    
    ##deep learning, H2O
    if (dl) {
        message ("Processing deep learning ... \n")
        
        library(h2o)
        
        threads = threads
        
        hidden = c(1000, 1000, 1000)
        
        epochs = 300
        
        #hidden = c(2000,2000,2000,2000);
        #epochs = 2000;
        nfolds = 3
        
        input_dropout_ratio =  0
        
        max_w2 = 10
        
        l1 = 0
        
        l2 = 0
        
        rho = 0.9
        
        epsilon = 1e-8
        
        #for dl parameters input
        if (file.exists("./dp_para.R"))
            source("./dp_para.R")
        
        dl = h2o.init(nthreads = threads)
        
        train.d = data.frame(data.t,
                             stringsAsFactors = F,
                             check.names = F)
        
        valid.d = data.frame(data.test.t,
                             stringsAsFactors = F,
                             check.names = F)
        
        train.d$response = class
        
        #valid.d$response = class.t;
        train.h2o = as.h2o(train.d)
        
        valid.h2o = as.h2o(valid.d)
        
        if (family == "binomial")  {
            train.h2o$response <- as.factor(train.h2o$response)
            
            #	valid.h2o$response <- as.factor(valid.h2o$response);
        }
        obs = as.vector(valid.d[, ncol(valid.d)])
        
        allheaders = colnames(train.d)
        
        myY = "response"
        
        myX = allheaders[-length(allheaders)]
        
        model.dp  = h2o.deeplearning(
            x = myX,
            y = myY,
            training_frame = train.h2o,
            hidden = hidden,
            epochs = epochs,
            nfolds = nfolds,
            input_dropout_ratio = input_dropout_ratio,
            max_w2 = max_w2,
            l1 = l1,
            l2 = l2,
            rho = rho,
            epsilon = epsilon,
            variable_importances = T
        )
        
        print(summary(model.dp))
        
        prediction = h2o.predict(model.dp, valid.h2o)
        
        p.ncol = dim(as.matrix(prediction))[2]
        
        pred.dl = as.vector(as.matrix(prediction[, p.ncol]))
        
        
        if (is.null(threshold)) {
            threshold = ifelse(family == "binomial", 1.5, mean(pred.dl, na.rm = T))
        }
        #threshold.dl = ifelse(family == "binomial", 0.5, mean(pred.dl, na.rm =
        #													  T))
        
        #threshold = mean(pred.dl, na.rm=T);
        if (!is.null(pdf)) {
            my_pred_plot(
                Prediction = pred.dl,
                Outcome = class.t,
                title = "Deep learning prediction",
                threshold = threshold.dl,
                positive = positive,
                reverse = reverse,
                ...
            )
            
            my_roc(
                outcome = class.t,
                prediction = pred.dl,
                title = "ROC of Deep learning prediction"
            )
        }
        
        roc.obj = roc(class.t, pred.dl, auc = TRUE)
        auc = as.numeric(roc.obj$auc)
        auc.dl = auc
        
        cat (" AUC = ", auc, "\n")
        
        #auc.out$dl.auc =  auc
        #pred.binomial = as.numeric(pred.dl > threshold)
        #if (positive == levels(outcome)[2]) {
        if (!reverse) {
            pred.binomial = as.numeric(pred.dl >= threshold)
        } else {
            pred.binomial = as.numeric(pred.dl < threshold)
        }
        cm = confusionMatrix(pred.binomial, class.t,
                             positive = positive,
                             ...)
        auc.out$auc$dl =  auc
        auc.out$cm$dl =  cm
        
    }
    
    if (!is.null(pdf)) {
        dev.off()
    }
    return (auc.out)
    
}

prediction_ROC_nopdf = function (pdf = NULL,
                                 ...)
{
    #obsolete, instead, using prediction_ROC (pdf=NULL)
    prediction_ROC(pdf = NULL, ...)
    
}

replace_zero_value = function (d) {
    name = names(d)
    d = as.numeric(d)
    zero_ind = which(d == 0)
    nega_ind = which(d < 0)
    if (length(nega_ind) > 0) {
        message (paste0("Negative data found: ", d[nega_ind]))
        d = d[-nega_ind]
    }
    d.ret = d
    if (length(zero_ind) > 0) {
        min.v = min(d[-zero_ind], na.rm = T) / 10
        d.ret[zero_ind] = min.v
    }
    names(d.ret) = name
    return (d.ret)
}

legend.col <- function(col, lev) {
    #adding contenous color legend in side
    opar <- par
    n <- length(col)
    bx <- par("usr")
    box.cx <- c(bx[2] + (bx[2] - bx[1]) / 1000,
                bx[2] + (bx[2] - bx[1]) / 1000 + (bx[2] - bx[1]) / 50)
    box.cy <- c(bx[3], bx[3])
    box.sy <- (bx[4] - bx[3]) / n
    xx <- rep(box.cx, each = 2)
    par(xpd = TRUE)
    for (i in 1:n) {
        yy <- c(
            box.cy[1] + (box.sy * (i - 1)),
            box.cy[1] + (box.sy * (i)),
            box.cy[1] + (box.sy * (i)),
            box.cy[1] + (box.sy * (i - 1))
        )
        polygon(xx, yy, col = col[i], border = col[i])
    }
    par(new = TRUE)
    plot(
        0,
        0,
        type = "n",
        ylim = c(min(lev), max(lev)),
        yaxt = "n",
        ylab = "",
        xaxt = "n",
        xlab = "",
        frame.plot = FALSE
    )
    axis(
        side = 4,
        las = 2,
        tick = FALSE,
        line = .25
    )
    par <- opar
}


plot_accu <-
    function (accu.rf,
              accu.nb,
              accu.svm,
              accu.nnet,
              pred_outd = "Prediction_results") {
        accu.d = data.frame(
            Value = c(
                accu.rf[, 1],
                accu.rf[, 2],
                accu.rf[, 3],
                accu.nb[, 1],
                accu.nb[, 2],
                accu.nb[, 3],
                accu.svm[, 1],
                accu.svm[, 2],
                accu.svm[, 3],
                accu.nnet[, 1],
                accu.nnet[, 2],
                accu.nnet[, 3]
            ),
            Type = c(
                rep("Accuracy", nrow(accu.rf)),
                rep("AccuracyLower", nrow(accu.rf)),
                rep("AccuracyUpper", nrow(accu.rf)),
                rep("Accuracy", nrow(accu.nb)),
                rep("AccuracyLower", nrow(accu.nb)),
                rep("AccuracyUpper", nrow(accu.nb)),
                rep("Accuracy", nrow(accu.svm)),
                rep("AccuracyLower", nrow(accu.svm)),
                rep("AccuracyUpper", nrow(accu.svm)),
                rep("Accuracy", nrow(accu.nnet)),
                rep("AccuracyLower", nrow(accu.nnet)),
                rep("AccuracyUpper", nrow(accu.nnet))
            ),
            Method = c(
                rep("RF", nrow(accu.rf) * ncol(accu.rf)),
                rep("NaiveBayes", nrow(accu.nb) * ncol(accu.nb)),
                rep("SVM", nrow(accu.svm) * ncol(accu.svm)),
                rep("NNET", nrow(accu.nnet) * ncol(accu.nnet))
            ),
            name = c(
                rownames(accu.rf),
                rownames(accu.nb),
                rownames(accu.svm),
                rownames(accu.nnet)
            )
        )
        
        str(accu.d)
        
        if (!file.exists(pred_outd)) {
            dir.create(pred_outd, recursive = T)
        }
        
        require(Rmisc)
        require(caret)
        pdf(paste0(pred_outd, "/accuracy.pdf"))
        #par(mfrow = c(1, 4))
        p1 = dotplot(accu.rf,
                     xlab = "RF accuracy",
                     ylab = "Feature profile",
                     type = "l")
        #p
        p2 = dotplot(accu.nb,
                     xlab = "NaiveBayes accuracy",
                     ylab = "Feature profile",
                     type = "l")
        #p
        p3 = dotplot(accu.svm,
                     xlab = "SVM accuracy",
                     ylab = "Feature profile",
                     type = "l")
        #p
        p4 = dotplot(accu.nnet,
                     xlab = "NNET accuracy",
                     ylab = "Feature profile",
                     type = "l")
        #p
        p5 = dotplot(
            reorder(name, Value) ~ Value | Method,
            data = accu.d,
            group = Type,
            type = "p",
            auto.key = list(
                space = "top",
                column = 3,
                cex = .5,
                title = "",
                cex.title = 1,
                lines = F,
                points = T
            ),
            layout = c(4, 1),
            xlab = "Accuracy",
            strip = T
        )
        
        multiplot(p1, p2, p3, p4, cols = 1)
        multiplot(p5, cols = 1)
        dev.off()
        
        pdf(paste0(pred_outd, "/accuracy_line.pdf"), 4, 6)
        p11 = dotplot(
            accu.rf,
            xlab = "RF independent test accuracy",
            ylab = "Feature profile",
            type = "l",
            auto.key = list(
                space = "top",
                column = 3,
                cex = 0.5,
                title = "95% CI",
                cex.title = 1,
                lines = T,
                points = F
            ),
            strip = T
        )
        p12 = dotplot(
            accu.nb,
            xlab = "NaiveBayes independent test accuracy",
            ylab = "Feature profile",
            type = "l",
            auto.key = list(
                space = "top",
                column = 3,
                cex = 0.5,
                title = "95% CI",
                cex.title = 1,
                lines = T,
                points = F
            ),
            strip = T
        )
        p13 = dotplot(
            accu.svm,
            xlab = "SVM independent test accuracy",
            ylab = "Feature profile",
            type = "l",
            auto.key = list(
                space = "top",
                column = 3,
                cex = 0.5,
                title = "95% CI",
                cex.title = 1,
                lines = T,
                points = F
            ),
            strip = T
        )
        p14 = dotplot(
            accu.nnet,
            xlab = "NNET independent test accuracy",
            ylab = "Feature profile",
            type = "l",
            auto.key = list(
                space = "top",
                column = 3,
                cex = 0.5,
                title = "95% CI",
                cex.title = 1,
                lines = T,
                points = F
            ),
            strip = T
        )
        multiplot(p11, p12, p13, p14, cols = 1)
        dev.off()
        
        pdf(paste0(pred_outd, "/accuracy_plot.pdf"), 8, 6)
        p15 = dotplot(
            reorder(name, Value) ~ Value | Method,
            data = accu.d,
            group = Type,
            type = "p",
            auto.key = list(
                space = "top",
                column = 3,
                cex = 0.5,
                title = "95% CI",
                cex.title = 1,
                lines = F,
                points = T
            ),
            layout = c(4, 1),
            xlab = "Accuracy",
            strip = T
        )
        multiplot(p15, cols = 1)
        dev.off()
        
    }

plot_accu_v2 <-
    function (pred.accu,
              pred_outd = "Prediction_results",
              plot.names = c("Accuracy", "AUC")
              ) {
        ml.algorithm = names(pred.accu)
        
        require(Rmisc)
        require(caret)
        p1 = list()
        p2 = list()
        if (!file.exists(pred_outd)) {
            dir.create(pred_outd, recursive = T)
        }
        Value = c()
        Type = c()
        Method = c()
        name = c()
        for (i in 1:length(pred.accu)) {
            accu = pred.accu[[i]]
            ml.method = ml.algorithm[i]
            Value = c(Value, accu[, plot.names[1]], accu[, plot.names[2]])
            Type = c(Type,
                     rep(plot.names[1], nrow(accu)),
                     rep(plot.names[2], nrow(accu)))
            Method = c(Method, rep(ml.method, nrow(accu) * 2))
            name   = c(name, rep(rownames(accu), 2))
            
            #plot
            p1[[length(p1) + 1]] = dotplot(
                accu[, c(plot.names[1], plot.names[2])],
                xlab = paste0(ml.method, " Accuracy & AUC"),
                ylab = "Feature profile",
                type = "l",
                auto.key = list(
                    space = "top",
                    column = 3,
                    #cex = 0.5,
                    title = "",
                    cex.title = 1,
                    lines = T,
                    points = F
                ),
                strip = T
            )
            p2[[length(p2) + 1]] = dotplot(
                accu[, c(plot.names[1], plot.names[2])],
                xlab = paste0(ml.method, " Accuracy & AUC"),
                ylab = "Feature profile",
                type = "l",
                auto.key = list(
                    space = "top",
                    column = 3,
                    #cex = 0.5,
                    title = "",
                    cex.title = 1,
                    lines = T,
                    points = F
                ),
                strip = T
            )
        }
        
        accu.d = data.frame(
            Value = Value,
            Type = Type,
            Method = Method,
            name = name
        )
        
        str(accu.d)
        #p
        p1.all = dotplot(
            reorder(name, Value) ~ Value | Method,
            data = accu.d,
            group = Type,
            #type = "p",
            auto.key = list(
                space = "top",
                column = length(ml.algorithm),
                #cex = .5,
                title = "",
                cex.title = 1,
                lines = F,
                points = T
            ),
            layout = c(length(pred.accu), 1),
            xlab = "Accuracy & AUC",
            strip = T
        )
        p2.all = dotplot(
            reorder(name, Value) ~ Value | Method,
            data = accu.d,
            group = Type,
            #type = "l",
            auto.key = list(
                space = "top",
                column = length(ml.algorithm),
                #cex = 0.5,
                title = "",
                cex.title = 1,
                lines = F,
                points = T
            ),
            layout = c(length(pred.accu), 1),
            xlab = "Accuracy & AUC",
            strip = T
        )
        pdf(paste0(pred_outd, "/accuracy_eachMethod.pdf"), family = "ArialMT")
        #multiplot(plotlist = p1, cols = 1)
        print (p1)
        #multiplot(plotlist = p2, cols = 1)
        dev.off()
        
        # pdf(paste0(pred_outd, "/accuracy_all.pdf"), family = "ArialMT")
        # #multiplot(plotlist = p1.all, cols = 1)
        # print (p1.all)
        # #multiplot(plotlist = p2.all, cols = 1)
        # dev.off()
        
    }

bagging_pred = function (code = "none",
                         ml.method = "svmRadial",
                         bootstrap.num = 100,
                         sample.perc = 0.8,
                         sample.replace = T,
                         training_rdata,
                         fork_script = "~/mybiotools/r/feature_selection_rf_svm_screen_02_fork.R",
                         outd = "temp_bagging",
                         CPUnum = 20,
                         tuneLength = 4,
                         repeats = 2)
{
    require(caret)
    load(training_rdata) #X, Y
    if (!file.exists(outd)) {
        dir.create(outd, recursive = T)
    }
    #set a seed
    set.seed(123)
    all.seed = sample(1:(bootstrap.num * 100), bootstrap.num, replace = sample.replace)
    sample.num = round(sample.perc * nrow(X))
    pbsids = c()
    all_out_rdata = c()
    for (j in 1:bootstrap.num)
    {
        message (paste0("For ", j , " out of ", bootstrap.num, " ... "))
        set.seed(all.seed[j])
        sample.i = sample(1:nrow(X), sample.num, replace = T)
        X = X[sample.i, ]
        
        Y = Y[sample.i]
        
        in_rdata  = paste0(
            outd,
            "/_tempin_",
            j,
            "_of_",
            bootstrap.num,
            "_PercOf_",
            sample.perc,
            "_code",
            code,
            ".rdata"
        )
        out_rdata = paste0(
            outd,
            "/_tempout_",
            j,
            "_of_",
            bootstrap.num,
            "_PercOf_",
            sample.perc,
            "_code",
            code,
            ".rdata"
        )
        all_out_rdata = c(all_out_rdata, out_rdata)
        
        #making input rdata
        if (!file.exists(in_rdata)) {
            save (X, Y, file = in_rdata)
        }
        #training
        if (!file.exists(out_rdata)) {
            CMD = paste(
                "Rscript",
                fork_script,
                CPUnum,
                in_rdata,
                ml.method,
                tuneLength,
                out_rdata,
                repeats,
                sep = " "
            )
            cat ("CMD: ", CMD, "\n", sep = "")
            pbsid = system(paste0("pbsv2.pl \"", CMD, "\"  -ppn ", CPUnum, " -q default"),
                           intern = T)
            pbsids = c(pbsids, pbsid)
        }
    }
    return(list(all_pbs_id = pbsids, all_out_rdata = all_out_rdata))
    
}

my_demography_no_response = function (phe,
                                      outf = "demography.tab",
                                      pheno.factor,
                                      pheno.cont) {
    #no statistics, for all
    options(
        "scipen" = 1,
        "digits" = 4,
        stringsAsFactors = FALSE
    )
    options(na.rm = T)
    
    #QC:
    diff.n = setdiff(pheno.factor, colnames(phe))
    if (length(diff.n) > 0)
        stop (paste0("Not all pheno.factor elements in phe: ", diff.n))
    diff.n = setdiff(pheno.cont, colnames(phe))
    if (length(diff.n) > 0)
        stop (paste0("Not all pheno.cont elements in phe: ", diff.n))
    dim(phe)
    
    cat(
        "Type",
        "sub-type",
        paste0("(%), ", "N=", dim(phe)[1]),
        "Count",
        "\n",
        sep = "\t",
        file = outf,
        append = F
    )
    
    for (p in pheno.factor)
    {
        cat (p, "\n")
        p.d = phe[, p]
        t.2 = table(p.d)
        # prop.t.2 = prop.table(t.2)
        for (l in names(t.2)) {
            count.case = as.numeric(t.2[l])
            ratio.case = round (count.case / nrow(phe), 3) * 100
            
            cat (
                p,
                l,
                ratio.case,
                count.case,
                "\n",
                sep = "\t",
                file = outf,
                append = T
            )
        }
        
    }
    
    cat("\n", "\n", file = outf, append = T)
    cat(
        "Type",
        "Mean",
        "SD",
        paste0("Count, N=",
               dim(phe)[1]),
        "\n",
        sep = "\t",
        file = outf,
        append = T
    )
    
    for (p in pheno.cont)
    {
        mean.case = mean(as.numeric(phe[, p]), na.rm = T)
        mean.case = round (mean.case, 3)
        sd.case = sd(phe[, p], na.rm = T)
        sd.case = round (sd.case, 3)
        num = sum(!is.na(phe[, p]))
        cat(
            p,
            mean.case,
            sd.case,
            num,
            "\n",
            sep = "\t",
            file = outf,
            append = T
        )
    }
}

detach_package <- function(pkg, character.only = FALSE)
{
    if (!character.only)
    {
        pkg <- deparse(substitute(pkg))
    }
    search_item <- paste("package", pkg, sep = ":")
    while (search_item %in% search())
    {
        detach(search_item,
               unload = TRUE,
               character.only = TRUE)
    }
}


multiClassSummary2 <- function (data, lev = NULL, model = NULL) {
    #Check data
    require(pROC)
    require(PRROC)
    require(ROCR)
    if (!all(levels(data[, "pred"]) == levels(data[, "obs"])))
        stop("levels of observed and predicted data do not match")
    
    ## Overall multinomial loss
    lloss <- mnLogLoss(data = data,
                       lev = lev,
                       model = model)
    
    #Calculate custom one-vs-all auROC curves for each class
    prob_stats <- lapply(levels(data[, "pred"]),
                         function(class) {
                             #Grab one-vs-all data for the class
                             pred <-
                                 ifelse(data[, "pred"] == class, 1, 0)
                             obs  <-
                                 ifelse(data[,  "obs"] == class, 1, 0)
                             prob <- data[, class]
                             
                             #Calculate one-vs-all AUC
                             if (length(table(obs)) == 1) {
                                 prob_stats = NA
                             } else {
                                 prob_stats <- as.vector(pROC::auc(obs, prob))
                                 names(prob_stats) <- c('auROC')                                 
                             }
                             return(prob_stats)
                         })
    roc_stats <- mean(unlist(prob_stats), na.rm =T)
 
    #Calculate custom one-vs-all auPRC curves for each class
    prob_stats2 <- lapply(levels(data[, "pred"]),
                          function(class) {
                              #Grab one-vs-all data for the class
                              pred <-
                                  ifelse(data[, "pred"] == class, 1, 0)
                              obs  <-
                                  ifelse(data[,  "obs"] == class, 1, 0)
                              prob <- data[, class]
                              
                              #Calculate one-vs-all AUC
                              if (length(table(obs)) == 1) {
                                  prob_stats2 = NA
                              } else {
                                  pred2 <- prediction(prob, obs)
                                  perf1 <-
                                      performance(pred2, "prec", "rec")
                                  x <-
                                      perf1@x.values[[1]] # Recall values
                                  y <-
                                      perf1@y.values[[1]] # Precision values
                                  y[1] = 1 #? not sure it is correct
                                  pr <- pr.curve(x, y, curve = F)
                                  auPRC = pr$auc.integral
                                  # auPRC = performance(pred, "auc")@y.values[[1]]
                                  prob_stats2 <-
                                      as.vector(auPRC)
                                  names(prob_stats2) <- c('auPRC')
                              }
                              return(prob_stats2)
                          })
    roc_stats2 <- mean(unlist(prob_stats2), na.rm = T)
    
    #Calculate confusion matrix-based statistics
    CM <- confusionMatrix(data[, "pred"], data[, "obs"])
    
    #Aggregate and average class-wise stats
    #Todo: add weights
    # RES: support two classes here as well
    #browser() # Debug
    if (length(levels(data[, "pred"])) == 2) {
        class_stats <- c(CM$byClass, roc_vals)
    } else {
        class_stats <- colMeans(CM$byClass)
        names(class_stats) <- paste("Mean", names(class_stats))
    }
    
    # Aggregate overall stats
    overall_stats <- c(CM$overall, lloss, Mean_auROC = roc_stats, Mean_auPRC = roc_stats2)
    
    # Combine overall with class-wise stats and remove some stats we don't want
    stats <- c(overall_stats, class_stats)
    stats <-
        stats[!names(stats) %in% c(
            'AccuracyNull',
            "AccuracyLower",
            "AccuracyUpper",
            "AccuracyPValue",
            "McnemarPValue",
            'Mean Prevalence',
            'Mean Detection Prevalence'
        )]
    
    names(stats) <- gsub('[[:blank:]]+', '_', names(stats))
    if (length(levels(data[, "pred"]) == 2)) {
        # Change name ordering to place most useful first
        # May want to remove some of these eventually
        stats <- stats[c(
            "logLoss",
            "Mean_auROC",
            "Mean_auPRC",
            "Mean_Sensitivity",
            "Mean_Specificity",
            "Accuracy",
            "Kappa",
            "Mean_Pos_Pred_Value",
            "Mean_Neg_Pred_Value",
            "Mean_Detection_Rate",
            "Mean_Balanced_Accuracy"
        )]
    }
    
    return(stats)
}
