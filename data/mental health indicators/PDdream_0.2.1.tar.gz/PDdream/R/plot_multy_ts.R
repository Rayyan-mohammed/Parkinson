plot_multy_ts <- function (
    #list of data frame
    ts.l,
    #the header of data frame that will be plotted
    dat.name,
    #colors
    col,
    #main
    main = NA,
    xlab = "Time",
    ylab = "",
    ... ) {
    
    if (length(ts.l) > length(col))
        stop ("Color length is less than list length.")
    all.data = c()
    len = c()
    for (i in 1:length(ts.l)) {
        all.data = c(all.data, ts.l[[i]][, dat.name])
        len = c(len, length(ts.l[[i]][, dat.name]))
    }
    if (is.na(main)) {
        main = paste0(dat.name)
    }
    plot(
        range(all.data, na.rm = T) ~ c(1, max(len, na.rm = T)),
        type = "n",
        main = main,
        xlab = xlab,
        ylab = ylab,
        ...
    )
    for (i in 1:length(ts.l)) {
        if (dim(ts.l[[i]])[1] < 10)
            next
        d = ts(ts.l[[i]][, dat.name])
        # plot.ts(d, add=T)
        lines(
            d,
            axes = FALSE,
            ann = FALSE,
            frame.plot = FALSE,
            col = col[i]
        )
    }
}
