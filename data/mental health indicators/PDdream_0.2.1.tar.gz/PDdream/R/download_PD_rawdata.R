download_PD_rawdata <- function (user=NA, password=NA)
{
    require(synapseClient)
    if (!is.na(user)) {
        synapseLogin(rememberMe = T,
                     username = user,
                     password = password)        
    } else {
        synapseLogin(rememberMe = T)
    }

    ###############################################################
    #for demo data
    demo_syntable <- synTableQuery("SELECT * FROM syn10146552")
    demo <- demo_syntable@values
    save(demo, file = "demo.rdata")
    healthCodeCol <- c(as.character(demo$healthCode))
    healthCodeList <-
        paste0(sprintf("'%s'", healthCodeCol), collapse = ", ")
    
    ###############################################################
    #for walking data 
    INPUT_WALKING_ACTIVITY_TABLE_SYNID = 'syn10146553'
    actv_walking_syntable <-
        synTableQuery(
            paste0(
                "SELECT * FROM  ",
                INPUT_WALKING_ACTIVITY_TABLE_SYNID,
                " WHERE healthCode IN ",
                "(",
                healthCodeList,
                ")"
            )
        )
    actv_walking <- actv_walking_syntable@values
    actv_walking$idx <- rownames(actv_walking)
    save(actv_walking, file = "actv_walking.rdata")
    
    DL_headers = colnames(actv_walking)[6:13]
   
    outbound_Walking_json_files <-
        synDownloadTableColumns(actv_walking_syntable, DL_headers)
    outbound_Walking_json_files <-
        data.frame(
            outbound_Walking_json_fileId = names(outbound_Walking_json_files),
            outbound_Walking_json_file = as.character(outbound_Walking_json_files)
        )
    outbound_Walking_json_files <- outbound_Walking_json_files %>%
        distinct(outbound_Walking_json_file, .keep_all = TRUE)
    save(outbound_Walking_json_files, file = "outbound_Walking_json_files.rdata")
 
    ###############################################################
    #for supplementary training data
    SYNID = 'syn10733835'
    supp_training_syntable <-
        synTableQuery(
            paste0(
                "SELECT * FROM  ",
                SYNID,
                " WHERE healthCode IN ",
                "(",
                healthCodeList,
                ")"
            )
        )   
    supp_training <- supp_training_syntable@values
    supp_training$idx <- rownames(supp_training)
    save(supp_training, file = "supp_training.rdata")
    
    DL_headers = colnames(supp_training)[6:13]
    
    supp_training_json_files <-
        synDownloadTableColumns(supp_training_syntable, DL_headers)
    supp_training_json_files <-
        data.frame(
            supp_training_json_fileId = names(supp_training_json_files),
            supp_training_json_file = as.character(supp_training_json_files)
        )
    supp_training_json_files <- supp_training_json_files %>%
        distinct(supp_training_json_file, .keep_all = TRUE)
    save(supp_training_json_files, file = "supp_training_json_files.rdata")
    
    ###############################################################
    #for testing data
    SYNID = 'syn10733842'
    testing_syntable <- synTableQuery("SELECT * FROM syn10733842")
    testing <- testing_syntable@values
    testing$idx <- rownames(testing)
    save(testing, file = "testing.rdata")
    
    DL_headers = colnames(testing)[6:13]
    testing_json_files <-
        synDownloadTableColumns(testing_syntable, DL_headers)
    testing_json_files <-
        data.frame(
            testing_json_fileId = names(testing_json_files),
            testing_json_file = as.character(testing_json_files)
        )
    testing_json_files <- testing_json_files %>%
        distinct(testing_json_file, .keep_all = TRUE)
    save(testing_json_files, file = "testing_json_files.rdata")   
    
}
