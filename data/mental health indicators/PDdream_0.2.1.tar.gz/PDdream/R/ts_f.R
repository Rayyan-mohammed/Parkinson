###############################################
## general functions
###############################################

## assign an object name on loading RData 
load_obj <- function(f){
  env <- new.env()
  nm <- load(f, env)[1]
  env[[nm]]
}

## calculate mean for each interval
interval_mean2 <- function(v, n){
  m   <- round(length(v)/n);
  fac <- factor(rep(1:n, each=m, length.out=length(v)), levels = 1:n)
  out <- tapply(v, fac, mean);
  return(out);
}

## calculate mean for each interval
interval_mean <- function(v, n){
  m  <- n + 1;
  qv <- round(seq(1, length(v), length.out=m)); 
  out.s <- NULL;
  for (i in 1:n){
    i1 <- i;
    i2 <- i+1;
    qv1 <- qv[i1];
    qv2 <- qv[i2];
    out.s <- c(out.s, mean(v[qv1:qv2], na.rm =T))
  }
  return(out.s);
}

## calculate maxima for each interval
interval_max <- function(v, n){
  m  <- n + 1;
  qv <- round(seq(1, length(v), length.out=m)); 
  out.s <- NULL;
  for (i in 1:n){
    i1 <- i;
    i2 <- i+1;
    qv1 <- qv[i1];
    qv2 <- qv[i2];
    out.s <- c(out.s, max(v[qv1:qv2], na.rm =T));
  }
  return(out.s);
}

## calculate minima for each interval
interval_min <- function(v, n){
  m  <- n + 1;
  qv <- round(seq(1, length(v), length.out=m)); 
  out.s <- NULL;
  for (i in 1:n){
    i1 <- i;
    i2 <- i+1;
    qv1 <- qv[i1];
    qv2 <- qv[i2];
    out.s <- c(out.s, min(v[qv1:qv2], na.rm =T));
  }
  return(out.s);
}

## lengthen a vector 
outn <- function(x, n){
  m   <- round(n/length(x));
  out <- rep(x, each = m, len = n);
  return(out);
}

## lengthen a vector to ten elements
out10 <- function(x){
  n   <- round(10/length(x));
  out <- rep(x, each = n, len = 10);
  return(out);
}

## lengthen a vector to 35 elements
out35 <- function(x){
  n   <- round(35/length(x));
  out <- rep(x, each = n, len = 35);
  return(out);
}

## calculate quantile means
v2q_m <- function(v, step){
  qv  <- quantile(v, seq(from = 0, to = 1, by = step));
  out <- tapply(v, findInterval(v, qv), mean);
  return(out);
}

## calculate quantile sd
v2q_sd <- function(v, step){
  qv  <- quantile(v, seq(from = 0, to = 1, by = step));
  out <- tapply(v, findInterval(v, qv), sd);
  return(out);
}

######################################################
## perform feature extraction from time series data set
#######################################################
## extract 35 features from one time series vector in 3 steps: step 1, use 
## wavelet algorithm, Discrete Wavelet Transform (DWT), to computes the 
## discrete wavelet transform coefficients for a univariate time series; step 
## 2, select 6 levels from N levels of wavelet coefficients and scaling
## coefficients respectively. Eleven interval means were calculated from the
## first two levels, 6 interval means were calculated in level 3. 4 and 1 
## interval means were calculated from last two levels respectively.
wavelets_f_mean <- function(v, f="haar"){
  wt  <- wavelets::dwt(v, filter = f, boundary = "periodic");
  ## select 6 levels by quantile
  l.q <- round(quantile(1:wt@level, seq(from = 0, to = 1, by = 0.2)));
  W.out <- wt@level;
  V.out <- wt@level;
  ## W value
  for(l.i in 1:length(l.q)){
    l       <- l.q[l.i];
    myW     <- as.numeric(unlist(wt@W[l]))
    if (l.i < 3){
      out.tmp <- interval_mean(myW, 11);
    } else if (l.i==3){
      out.tmp <- interval_mean(myW, 6);
    } else if (l.i==4){
      out.tmp <- interval_mean(myW, 4);
    } else {
      out.tmp <- mean(myW);
    }
    out.tmp <- round(out.tmp, 3);
    W.out <- c(W.out, out.tmp);
  }
  ## V value
  for(l.i in 1:length(l.q)){
    l       <- l.q[l.i];
    myV     <- as.numeric(unlist(wt@V[l]))
    if (l.i < 3){
      out.tmp <- interval_mean(myV, 11);
    } else if (l.i==3){
      out.tmp <- interval_mean(myV, 6);
    } else if (l.i==4){
      out.tmp <- interval_mean(myV, 4);
    } else {
      out.tmp <- mean(myV);
    }
    out.tmp <- round(out.tmp, 3);
    V.out <- c(V.out, out.tmp);
  }
  return(list(W=W.out, V=V.out));
}

wavelets_f_min <- function(v, f="haar"){
  wt  <- wavelets::dwt(v, filter = f, boundary = "periodic");
  ## select 6 levels by quantile
  l.q <- round(quantile(1:wt@level, seq(from = 0, to = 1, by = 0.2)));
  W.out <- wt@level;
  V.out <- wt@level;
  ## W value
  for(l.i in 1:length(l.q)){
    l       <- l.q[l.i];
    myW     <- as.numeric(unlist(wt@W[l]))
    if (l.i < 3){
      out.tmp <- interval_min(myW, 11);
    } else if (l.i==3){
      out.tmp <- interval_min(myW, 6);
    } else if (l.i==4){
      out.tmp <- interval_min(myW, 4);
    } else {
      out.tmp <- min(myW);
    }
    out.tmp <- round(out.tmp, 3);
    W.out <- c(W.out, out.tmp);
  }
  ## V value
  for(l.i in 1:length(l.q)){
    l       <- l.q[l.i];
    myV     <- as.numeric(unlist(wt@V[l]))
    if (l.i < 3){
      out.tmp <- interval_min(myV, 11);
    } else if (l.i==3){
      out.tmp <- interval_min(myV, 6);
    } else if (l.i==4){
      out.tmp <- interval_min(myV, 4);
    } else {
      out.tmp <- min(myV);
    }
    out.tmp <- round(out.tmp, 3);
    V.out <- c(V.out, out.tmp);
  }
  return(list(W=W.out, V=V.out));
}

wavelets_f_max <- function(v, f="haar"){
  wt  <- wavelets::dwt(v, filter = f, boundary = "periodic");
  ## select 6 levels by quantile
  l.q <- round(quantile(1:wt@level, seq(from = 0, to = 1, by = 0.2)));
  W.out <- wt@level;
  V.out <- wt@level;
  ## W value
  for(l.i in 1:length(l.q)){
    l       <- l.q[l.i];
    myW     <- as.numeric(unlist(wt@W[l]))
    if (l.i < 3){
      out.tmp <- interval_max(myW, 11);
    } else if (l.i==3){
      out.tmp <- interval_max(myW, 6);
    } else if (l.i==4){
      out.tmp <- interval_max(myW, 4);
    } else {
      out.tmp <- max(myW);
    }
    out.tmp <- round(out.tmp, 3);
    W.out <- c(W.out, out.tmp);
  }
  ## V value
  for(l.i in 1:length(l.q)){
    l       <- l.q[l.i];
    myV     <- as.numeric(unlist(wt@V[l]))
    if (l.i < 3){
      out.tmp <- interval_max(myV, 11);
    } else if (l.i==3){
      out.tmp <- interval_max(myV, 6);
    } else if (l.i==4){
      out.tmp <- interval_max(myV, 4);
    } else {
      out.tmp <- max(myV);
    }
    out.tmp <- round(out.tmp, 3);
    V.out <- c(V.out, out.tmp);
  }
  return(list(W=W.out, V=V.out));
}

## mean of each quantile
wavelets_f_mean2 <- function(v, f="haar"){
  wt  <- wavelets::dwt(v, filter = f, boundary = "periodic");
  ## select 6 levels by quantile
  l.q <- round(quantile(1:wt@level, seq(from = 0, to = 1, by = 0.2)));
  W.out <- wt@level;
  V.out <- wt@level;
  ## W value
  for(l.i in 1:length(l.q)){
    l       <- l.q[l.i];
    myW     <- as.numeric(unlist(wt@W[l]))
    if (l.i < 3){
      out.tmp <- v2q_m(myW, 0.1);
    } else if (l.i==3){
      out.tmp <- v2q_m(myW, 0.2);
    } else if (l.i==4){
      out.tmp <- v2q_m(myW, 0.3);
    } else {
      out.tmp <- mean(myW);
    }
    out.tmp <- round(out.tmp, 3);
    W.out <- c(W.out, out.tmp);
  }
  ## V value
  for(l.i in 1:length(l.q)){
    l       <- l.q[l.i];
    myV     <- as.numeric(unlist(wt@V[l]))
    if (l.i < 3){
      out.tmp <- v2q_m(myV, 0.1);
    } else if (l.i==3){
      out.tmp <- v2q_m(myV, 0.2);
    } else if (l.i==4){
      out.tmp <- v2q_m(myV, 0.3);
    } else {
      out.tmp <- mean(myV);
    }
    out.tmp <- round(out.tmp, 3);
    V.out <- c(V.out, out.tmp);
  }
  return(list(W=W.out, V=V.out));
}

do_svd <- function(v){
  out   <- svd(v);
  out.f <- t(out$u) %*% v %*% out$v;
  return(as.vector(out.f));
}

## dct
## Perform a Fast Fourier Transform (FFT) to extract 10 features for single
## time series data by the everages for 10 interval regions. 
do_dft <- function(v, l){
  v.ts  <- stats::ts(v);
  Y     <- stats::fft(v)
  out   <- sqrt(Re(Y)^2+Im(Y)^2)*2/length(v);
  out.s <- interval_mean(out, l);
  return(out.s);
}

## Perform a Fast Fourier Transform (FFT) to extract 10 features for single
## time series data by the maximas in 10 interval regions. 
do_dft_max <- function(v, l){
  v.ts  <- stats::ts(v);
  Y     <- stats::fft(v)
  out   <- sqrt(Re(Y)^2+Im(Y)^2)*2/length(v);
  out.s <- interval_max(out, l);
  return(out.s);
}

## Perform a Fast Fourier Transform (FFT) to extract 10 features for single
## time series data by the minimas in 10 interval regions using fft function. 
do_dft_min <- function(v, l){
  v.ts  <- stats::ts(v);
  Y     <- stats::fft(v)
  out   <- sqrt(Re(Y)^2+Im(Y)^2)*2/length(v);
  out.s <- interval_min(out, l);
  return(out.s);
}

## Perform Piecewise Aggregate Approximation (PAA) to extract 10 features for 
## single time series data by paa funcion of R package jmotif.
do_paa <- function(v, l){
  out <- jmotif::paa(v, paa_num=l);
  return(out);
}

## Perform Power Spectral Density (PSD) to extract 10 features for single
## time series data by interval means using psdcore funcion of R package psd . 
do_pds <- function(v, l){
  out   <- psd::psdcore(v);
  out   <- out$spec;
  out.s <- interval_mean(out, l);
  return(out.s);
}

## Perform Power Spectral Density (PSD) to extract 10 features for single
## time series data by interval maximas using psdcore funcion of R package psd . 
do_pds_max <- function(v, l){
  out   <- psd::psdcore(v);
  out   <- out$spec;
  out.s <- interval_max(out, l);
  return(out.s);
}

## Perform Power Spectral Density (PSD) to extract 10 features for single
## time series data by interval minimas using psdcore funcion of R package psd . 
do_pds_min <- function(v, l){
  out   <- psd::psdcore(v);
  out   <- out$spec;
  out.s <- interval_min(out, l);
  return(out.s);
}

## Perform Perceptually Important Points (PIPS) to extract 10 features for
## single time series data by GetPIPs funcion of R package TSPatternQuery.
do_pip <- function(v, l){
  out <- TSPatternQuery::GetPIPs(v, l);
  if (length(out) != l){
    out <- outn(out, l);
  }    
  return(out);
}

