select_tsdata <- function (
    #data frame with one unique sample
    dat,
    #data time header
    timestamp = "timestamp",
    #data sample header
    idx = "idx",
    # ts period, NA means auto determined
    period.length = NA,
    #how many periods will be returned
    return.period.times = 6,
    #period +/- length as normal data
    period.updown = 8
    ) {
    
    out = strsplit(as.character(dat [, timestamp]), "\\.")
    out2  <- do.call(rbind, out)
    out2.t = table(out2[, 1])
    if (is.na(period.length)) {
        #find a proper period.length
        out2.t.t = table(as.numeric(out2.t))
        or.out2.i = order(out2.t.t, decreasing = T)
        period.length = as.numeric(names(out2.t.t[or.out2.i])[1])
    }
    
    normal.i = which(
        as.numeric(out2.t) > (period.length - period.updown) &
            as.numeric(out2.t) < (period.length + period.updown)
    )
    if (return.period.times < length(normal.i)) {
        median.l = median(normal.i)
        half.return.l = as.integer(return.period.times / 2)
        keep.range = c((median.l - half.return.l + 1), (median.l - half.return.l + 6))
        normal.i = normal.i[keep.range[1]:keep.range[2]]
    }
    normal.time = names(out2.t[normal.i])
    ret.i = which(out2[, 1] %in% normal.time)
    return (dat[ret.i,])
}

#for debug
dat=
timestamp = "timestamp"
idx = "idx"
period.length = NA
return.period.times = 6
period.updown = 8
